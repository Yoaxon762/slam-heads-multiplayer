'use strict';
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: true, methods: ['GET', 'POST'] },
  pingInterval: 25000,
  pingTimeout: 20000,
  maxHttpBufferSize: 1e6,
});
const PORT = process.env.PORT || 3000;
const rooms = new Map();

app.get('/', (_req, res) => res.type('text').send('Slam Heads multiplayer server is running.'));
app.get('/health', (_req, res) => res.json({ ok: true, rooms: rooms.size }));

function makeCode() {
  let code;
  do {
    code = String(Math.floor(100000 + Math.random() * 900000));
  } while (rooms.has(code));
  return code;
}
function fail(socket, message) { socket.emit('room:error', { message }); }
function status(room) {
  const ready = !!room.host && !!room.guest && !room.started;
  io.to(room.code).emit('room:status', { code: room.code, players: (room.host ? 1 : 0) + (room.guest ? 1 : 0), ready, started: room.started });
}
function clearSocketRoom(socket, notify = true) {
  const code = socket.data.roomCode;
  if (!code) return;
  const room = rooms.get(code);
  socket.leave(code);
  socket.data.roomCode = null;
  socket.data.role = null;
  if (!room) return;
  if (room.host === socket.id) {
    if (notify) socket.to(code).emit('room:closed');
    rooms.delete(code);
  } else if (room.guest === socket.id) {
    room.guest = null;
    room.started = false;
    if (notify) io.to(code).emit('room:status', { code, players: room.host ? 1 : 0, ready: false, started: false });
  }
}

io.on('connection', socket => {
  socket.data.roomCode = null;
  socket.data.role = null;
  socket.on('room:create', () => {
    clearSocketRoom(socket, false);
    if (rooms.size > 1000) return fail(socket, 'The server is busy. Try again in a moment.');
    const code = makeCode();
    const room = { code, host: socket.id, guest: null, started: false, createdAt: Date.now() };
    rooms.set(code, room);
    socket.join(code);
    socket.data.roomCode = code;
    socket.data.role = 0;
    socket.emit('room:created', { code, role: 0 });
    status(room);
  });
  socket.on('room:join', payload => {
    const code = String(payload && payload.code || '').replace(/\D/g, '').slice(0, 6);
    if (!/^[0-9]{6}$/.test(code)) return fail(socket, 'Enter a valid 6-digit room code.');
    const room = rooms.get(code);
    if (!room) return fail(socket, 'That room was not found. Check the code and try again.');
    if (room.started) return fail(socket, 'That match has already started. Ask your friend to create a new room.');
    if (room.guest && room.guest !== socket.id) return fail(socket, 'That room is full. Ask your friend for another room code.');
    clearSocketRoom(socket, false);
    room.guest = socket.id;
    socket.join(code);
    socket.data.roomCode = code;
    socket.data.role = 1;
    socket.emit('room:joined', { code, role: 1 });
    status(room);
  });
  socket.on('room:start', async payload => {
    const code = socket.data.roomCode;
    const room = rooms.get(code);
    if (!room || room.host !== socket.id) return fail(socket, 'Only the room host can start the match.');
    if (!room.guest) return fail(socket, 'Wait for your friend to join before starting.');
    room.started = true;
    const len = [60, 120, 180].includes(Number(payload && payload.len)) ? Number(payload.len) : 120;
    const peers = await io.in(code).fetchSockets();
    for (const peer of peers) peer.emit('game:start', { code, role: peer.data.role, len });
  });
  socket.on('player:input', payload => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || !room.started || socket.data.role !== 1 || room.host === null) return;
    const raw = payload && payload.intent || {};
    const intent = {};
    for (const key of ['left', 'right', 'jump', 'shoot', 'pass', 'power']) intent[key] = !!raw[key];
    io.to(room.host).emit('player:input', { role: 1, intent });
  });
  socket.on('player:look', payload => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || socket.data.role !== 1 || !room.host) return;
    const raw = payload && payload.look;
    if (!raw || typeof raw !== 'object') return;
    const look = {};
    for (const key of ['skin', 'hair', 'style', 'outfit', 'name', 'num', 'band', 'beard', 'headR']) {
      const value = raw[key];
      if (['string', 'number', 'boolean'].includes(typeof value)) look[key] = value;
    }
    io.to(room.host).emit('player:look', { role: 1, look });
  });
  socket.on('game:snapshot', payload => {
    const room = rooms.get(socket.data.roomCode);
    if (!room || !room.started || socket.data.role !== 0 || !room.guest) return;
    if (!payload || typeof payload !== 'object') return;
    // Snapshot data is produced by the game client; cap payload size and only forward to the paired guest.
    let safe;
    try {
      const encoded = JSON.stringify(payload);
      if (encoded.length > 700000) return;
      safe = JSON.parse(encoded);
    } catch (_) { return; }
    io.to(room.guest).emit('game:snapshot', safe);
  });
  socket.on('room:leave', () => clearSocketRoom(socket, true));
  socket.on('disconnect', () => clearSocketRoom(socket, true));
});

// Reap abandoned empty rooms periodically.
setInterval(() => {
  const cutoff = Date.now() - 6 * 60 * 60 * 1000;
  for (const [code, room] of rooms) if (!room.host && !room.guest || room.createdAt < cutoff && !room.started) rooms.delete(code);
}, 60 * 1000).unref();

server.listen(PORT, '0.0.0.0', () => console.log(`Slam Heads multiplayer server listening on ${PORT}`));
