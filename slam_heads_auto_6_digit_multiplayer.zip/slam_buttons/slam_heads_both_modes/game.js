/* SLAM HEADS — 2D arcade basketball
   Coordinate system: logical 1280x720, origin top-left, +x right, +y down.
   Team 0 (orange, "Blaze") attacks the RIGHT hoop. Team 1 (teal, "Tide") attacks the LEFT hoop. */
(() => {
'use strict';

// ───────────────────────── constants ─────────────────────────
const W = 1280, H = 720, FLOOR = 618;
const G_BALL = 1500, G_PLAYER = 2150;
const BALL_R = 14;
const JUMP_V = 800, SHOT_JUMP_V = 760;
const RUN_SPEED = 400;
const SHOT_CLOCK = 12;
const THREE_DIST = 455;
const RIM_Y = 338;

const HOOPS = [
  { id: 0, dir: -1, boardX: 74, backX: 88, frontX: 160 },   // left hoop
  { id: 1, dir: 1, boardX: 1206, backX: 1192, frontX: 1120 }, // right hoop
];
for (const h of HOOPS) { h.cx = (h.backX + h.frontX) / 2; h.minX = Math.min(h.backX, h.frontX); h.maxX = Math.max(h.backX, h.frontX); h.net = 0; h.shake = 0; }
const attackHoop = (team) => HOOPS[team === 0 ? 1 : 0];
const defendHoop = (team) => HOOPS[team === 0 ? 0 : 1];

const TEAMS = [
  { name: 'BLAZE', main: '#ff7a1a', dark: '#b84a00', trim: '#ffe2c4', num: '#fff6ea' },
  { name: 'TIDE', main: '#19c3b4', dark: '#0b7a72', trim: '#d3fff9', num: '#f2fffd' },
];
const SKINS = ['#f2c39b', '#c98b5e', '#8d5a3b', '#5e3a24', '#e8b48a', '#a86b44'];
const HAIRS = ['#1b1410', '#3b2414', '#d9a441', '#7a3b1a', '#121212', '#e6e0d8'];
const STYLES = ['fade', 'afro', 'spike', 'bald', 'bun', 'flat'];
const NAMES = ['DUNKS', 'BIGZ', 'MOOSE', 'JJ', 'FLASH', 'TANK', 'ACE', 'NOVA', 'RICO', 'BOOGIE', 'KO', 'SLIM'];

const DIFF = {
  easy:   { react: 0.36, timing: 0.32, steal: 0.25, block: 0.22, speed: 0.84, iq: 0.4 },
  normal: { react: 0.24, timing: 0.2,  steal: 0.45, block: 0.4,  speed: 0.94, iq: 0.7 },
  hard:   { react: 0.14, timing: 0.11, steal: 0.75, block: 0.58, speed: 1.0, iq: 0.95 },
};
function getDiff() {
  if (state.cfg.mode !== 'tournament') return DIFF[state.cfg.diff] || DIFF.normal;
  // Five rounds steadily raise reaction speed, shot timing, steals, blocks, and decision quality.
  const t = clamp((state.tournamentRound - 1) / 4, 0, 1);
  const e = DIFF.easy, h = DIFF.hard;
  return {
    react: lerp(e.react, h.react, t), timing: lerp(e.timing, h.timing, t),
    steal: lerp(e.steal, h.steal, t), block: lerp(e.block, h.block, t),
    speed: lerp(e.speed, h.speed, t), iq: lerp(e.iq, h.iq, t),
  };
}

// ───────────────────────── utils ─────────────────────────
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const rand = (a = 0, b = 1) => a + Math.random() * (b - a);
const pick = (arr) => arr[(Math.random() * arr.length) | 0];
const gauss = () => { let u = 0, v = 0; while (!u) u = Math.random(); while (!v) v = Math.random(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v); };
const sign = (v) => (v < 0 ? -1 : 1);

// ───────────────────────── canvas ─────────────────────────
const canvas = document.getElementById('game');
const ctx = canvas.getContext('2d');
let scale = 1, dpr = 1;
function resize() {
  dpr = Math.min(window.devicePixelRatio || 1, 2);
  const vw = window.innerWidth, vh = window.innerHeight;
  scale = Math.min(vw / W, vh / H);
  const cw = Math.floor(W * scale), ch = Math.floor(H * scale);
  canvas.style.width = cw + 'px';
  canvas.style.height = ch + 'px';
  canvas.width = Math.floor(cw * dpr);
  canvas.height = Math.floor(ch * dpr);
}
window.addEventListener('resize', resize);
resize();

// ───────────────────────── audio ─────────────────────────
const Audio = {
  ctx: null, master: null, music: null, sfx: null, muted: false, noiseBuf: null, musicOn: true, step: 0, nextT: 0, timer: null,
  init() {
    if (this.ctx) { this.ctx.resume(); return; }
    try {
      const AC = window.AudioContext || window.webkitAudioContext;
      this.ctx = new AC();
    } catch (e) { return; }
    const c = this.ctx;
    this.master = c.createGain(); this.master.gain.value = 0.8; this.master.connect(c.destination);
    this.sfx = c.createGain(); this.sfx.gain.value = 0.9; this.sfx.connect(this.master);
    this.music = c.createGain(); this.music.gain.value = 0.22; this.music.connect(this.master);
    const len = c.sampleRate * 2;
    this.noiseBuf = c.createBuffer(1, len, c.sampleRate);
    const d = this.noiseBuf.getChannelData(0);
    for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
    this.startMusic();
  },
  setMuted(m) { this.muted = m; if (this.master) this.master.gain.value = m ? 0 : 0.8; },
  tone(freq, dur, type = 'sine', vol = 0.3, slideTo = null, when = 0, dest = null) {
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime + when;
    const o = c.createOscillator(), g = c.createGain();
    o.type = type; o.frequency.setValueAtTime(freq, t);
    if (slideTo) o.frequency.exponentialRampToValueAtTime(slideTo, t + dur);
    g.gain.setValueAtTime(vol, t); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    o.connect(g).connect(dest || this.sfx); o.start(t); o.stop(t + dur + 0.02);
  },
  noise(dur, vol = 0.3, ftype = 'bandpass', freq = 1000, q = 1, when = 0, dest = null, attack = 0.002) {
    if (!this.ctx) return;
    const c = this.ctx, t = c.currentTime + when;
    const s = c.createBufferSource(); s.buffer = this.noiseBuf;
    const f = c.createBiquadFilter(); f.type = ftype; f.frequency.value = freq; f.Q.value = q;
    const g = c.createGain();
    g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(vol, t + attack); g.gain.exponentialRampToValueAtTime(0.0008, t + dur);
    s.connect(f).connect(g).connect(dest || this.sfx); s.start(t, Math.random()); s.stop(t + dur + 0.05);
  },
  bounce(v = 1) { this.tone(150, 0.12, 'sine', 0.35 * v, 55); this.noise(0.05, 0.12 * v, 'lowpass', 900); },
  swish() { this.noise(0.32, 0.28, 'bandpass', 4200, 0.8, 0, null, 0.03); this.noise(0.2, 0.12, 'highpass', 6000, 0.5, 0.05); },
  rim(v = 1) { this.tone(620, 0.25, 'triangle', 0.18 * v); this.tone(1240, 0.18, 'sine', 0.08 * v); this.tone(905, 0.2, 'square', 0.03 * v); },
  board() { this.noise(0.12, 0.3, 'lowpass', 500); this.tone(110, 0.1, 'sine', 0.25); },
  dunk() {
    // Layered arcade slam: metallic rim, low impact, and a short bright hit.
    this.rim(1.8);
    this.tone(62, 0.5, 'sine', 0.62, 32);
    this.noise(0.34, 0.34, 'lowpass', 280);
    this.tone(420, 0.12, 'triangle', 0.11, 180, 0.025);
    this.cheer(0.85);
  },
  impact() {
    this.noise(0.16, 0.22, 'lowpass', 520);
    this.tone(115, 0.2, 'triangle', 0.2, 58);
  },
  trailEquip() { this.tone(520, 0.08, 'triangle', 0.09, 920); this.tone(780, 0.14, 'sine', 0.07, 1240, 0.06); this.noise(0.12, 0.05, 'highpass', 4200, 0.8, 0.02); },
  crowdPop() {
    this.tone(740, 0.09, 'sine', 0.08);
    this.tone(980, 0.12, 'sine', 0.07, null, 0.07);
    this.noise(0.55, 0.12, 'bandpass', 1800, 0.5, 0.02, null, 0.08);
  },
  whoosh() { this.noise(0.16, 0.16, 'bandpass', 1400, 0.7, 0, null, 0.04); },
  squeak() { this.tone(1900, 0.06, 'sine', 0.035, 2600); },
  jump() { this.tone(260, 0.1, 'sine', 0.06, 420); },
  steal() { this.whoosh(); this.tone(520, 0.08, 'square', 0.06, 880); },
  block() { this.noise(0.12, 0.4, 'lowpass', 700); this.tone(180, 0.15, 'square', 0.12, 90); },
  whistle() { if (!this.ctx) return; const c = this.ctx, t = c.currentTime; const o = c.createOscillator(), g = c.createGain(), l = c.createOscillator(), lg = c.createGain(); o.frequency.value = 2900; l.frequency.value = 38; lg.gain.value = 140; l.connect(lg).connect(o.frequency); g.gain.setValueAtTime(0.0001, t); g.gain.linearRampToValueAtTime(0.12, t + 0.02); g.gain.setValueAtTime(0.12, t + 0.35); g.gain.exponentialRampToValueAtTime(0.0008, t + 0.45); o.connect(g).connect(this.sfx); o.start(t); l.start(t); o.stop(t + 0.5); l.stop(t + 0.5); },
  buzzer() { this.tone(196, 0.9, 'sawtooth', 0.14); this.tone(247, 0.9, 'sawtooth', 0.1); },
  cheer(big = 1) { this.noise(1.6 * big, 0.16 * big, 'bandpass', 900, 0.4, 0, null, 0.15); this.noise(1.2 * big, 0.08 * big, 'bandpass', 2400, 0.6, 0.05, null, 0.2); },
  meter() { this.tone(880, 0.05, 'sine', 0.05); },
  green() { this.tone(1320, 0.12, 'sine', 0.12); this.tone(1760, 0.16, 'sine', 0.08, null, 0.06); },
  // simple boom-bap loop scheduler
  startMusic() {
    const c = this.ctx; this.nextT = c.currentTime + 0.1; this.step = 0;
    const bpm = 94, sixteenth = 60 / bpm / 4;
    const bass = [43, 0, 0, 43, 0, 0, 46, 0, 41, 0, 0, 41, 0, 38, 0, 0];
    const kick = [1, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0];
    const snare = [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 1];
    const sched = () => {
      if (!this.ctx) return;
      while (this.nextT < c.currentTime + 0.25) {
        const s = this.step % 16, bar = Math.floor(this.step / 16) % 4;
        const when = this.nextT - c.currentTime;
        if (this.musicOn) {
          if (kick[s]) this.tone(120, 0.22, 'sine', 0.55, 40, when, this.music);
          if (snare[s]) { this.noise(0.16, 0.32, 'bandpass', 1800, 0.6, when, this.music); this.tone(190, 0.08, 'triangle', 0.15, 140, when, this.music); }
          if (s % 2 === 0) this.noise(0.04, s % 4 === 2 ? 0.11 : 0.06, 'highpass', 8000, 0.7, when, this.music);
          const n = bass[s]; if (n) { const tr = bar === 3 ? 3 : 0; this.tone(440 * Math.pow(2, (n + tr - 69) / 12), sixteenth * 2.2, 'triangle', 0.32, null, when, this.music); }
          if (s === 0 || s === 8) { const root = bar % 2 ? 62 : 65; [0, 3, 7].forEach((iv) => this.tone(440 * Math.pow(2, (root + iv - 69) / 12), sixteenth * 3.5, 'sine', 0.05, null, when, this.music)); }
        }
        this.nextT += sixteenth; this.step++;
      }
    };
    this.timer = setInterval(sched, 60);
  },
};

// ───────────────────────── input ─────────────────────────
const keys = {};
const touchState = { left: false, right: false, jump: false, shoot: false, pass: false, power: false };
const touchState2 = { left: false, right: false, jump: false, shoot: false };
window.addEventListener('keydown', (e) => {
  if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight', 'Space'].includes(e.code)) e.preventDefault();
  if (e.repeat) return;
  keys[e.code] = true;
  if (e.code === 'KeyP' || e.code === 'Escape') togglePause();
  if (e.code === 'KeyM') toggleMute();
  if (e.code === 'Enter' && state.mode === 'menu') startGame();
});
window.addEventListener('keyup', (e) => { keys[e.code] = false; });
window.addEventListener('blur', () => { for (const k in keys) keys[k] = false; });

function humanIntent(slot) {
  const k = keys, T = touchState;
  if (slot === 0) {
    const solo = state.cfg.mode !== 'pvp';
    return {
      left: k.KeyA || (solo && k.ArrowLeft) || T.left,
      right: k.KeyD || (solo && k.ArrowRight) || T.right,
      jump: k.KeyW || (solo && (k.ArrowUp || k.Space)) || T.jump,
      shoot: k.KeyS || (solo && (k.ArrowDown || k.KeyJ)) || T.shoot,
      pass: k.KeyE || (solo && (k.KeyK || k.ShiftRight)) || T.pass,
      power: k.KeyQ || T.power,
    };
  }
  const T2 = state.cfg.mode === 'pvp' ? touchState2 : touchState;
  return { left: k.ArrowLeft || T2.left, right: k.ArrowRight || T2.right, jump: k.ArrowUp || T2.jump, shoot: k.ArrowDown || T2.shoot, pass: k.Slash || k.ShiftRight || (state.cfg.mode !== 'pvp' && touchState.pass), power: k.KeyN || (state.cfg.mode !== 'pvp' && touchState.power) };
}

// Persistent local coin wallet, power-ups, and cosmetic ball trails.
const SHOP_POWERS = {
  boost: { name: 'ALL-STAR BOOST', cost: 0, icon: '⚡', desc: 'Balanced speed, jump and steal boost for 3 seconds.' },
  speed: { name: 'TURBO SNEAKERS', cost: 120, icon: '👟', desc: 'Move 45% faster while your power is active.' },
  jump: { name: 'SKY WALKER', cost: 150, icon: '🚀', desc: 'Huge jumps and extra hang time for big dunks.' },
  steal: { name: 'LOCKDOWN', cost: 140, icon: '🧤', desc: 'A much stronger chance to swipe the ball.' },
  sniper: { name: 'GREEN MACHINE', cost: 180, icon: '🎯', desc: 'Longer power duration and a better shot-release window.' },
};
const BALL_TRAILS = {
  classic: { name: 'CLASSIC FIRE', cost: 0, icon: '🔥', desc: 'Hot orange embers with a warm glow.', colors: ['#ff541f','#ffb21c','#fff0a0'], style: 'fire' },
  ice: { name: 'FROST BITE', cost: 100, icon: '❄️', desc: 'Icy blue streaks and sparkling frost.', colors: ['#65e8ff','#9db7ff','#ffffff'], style: 'ice' },
  neon: { name: 'NEON CYCLONE', cost: 150, icon: '💜', desc: 'Electric purple and pink arcade glow.', colors: ['#ff48d7','#9b5cff','#53eaff'], style: 'neon' },
  toxic: { name: 'TOXIC GREEN', cost: 180, icon: '☢️', desc: 'Lime-green energy with bright sparks.', colors: ['#b8ff26','#38e878','#efff9a'], style: 'toxic' },
  gold: { name: 'GOLDEN MVP', cost: 250, icon: '👑', desc: 'A premium gold trail for highlight plays.', colors: ['#fff0a0','#ffc52e','#ff8a19'], style: 'gold' },
  rainbow: { name: 'RAINBOW POP', cost: 300, icon: '🌈', desc: 'A shifting multicolor trail.', colors: ['#ff4d6d','#ffcf4d','#55f3c1','#6d8cff','#d76dff'], style: 'rainbow' },
};
const COSMETICS = {
  skin: [
    { id:'skin_1', name:'Warm Beige', value:'#f2c39b', cost:0, swatch:'#f2c39b' },
    { id:'skin_2', name:'Golden Tan', value:'#c98b5e', cost:0, swatch:'#c98b5e' },
    { id:'skin_3', name:'Caramel', value:'#a86b44', cost:0, swatch:'#a86b44' },
    { id:'skin_4', name:'Deep Brown', value:'#5e3a24', cost:0, swatch:'#5e3a24' },
    { id:'skin_5', name:'Rose Tan', value:'#e8b48a', cost:0, swatch:'#e8b48a' },
    { id:'skin_6', name:'Rich Cocoa', value:'#75452d', cost:0, swatch:'#75452d' },
    { id:'skin_7', name:'Light Peach', value:'#f7d2b0', cost:0, swatch:'#f7d2b0' },
  ],
  style: [
    { id:'style_fade', name:'Fresh Fade', value:'fade', cost:0, icon:'💈' },
    { id:'style_afro', name:'Big Afro', value:'afro', cost:0, icon:'🌟' },
    { id:'style_spike', name:'Spiky', value:'spike', cost:60, icon:'⚡' },
    { id:'style_bald', name:'Bald', value:'bald', cost:0, icon:'🧢' },
    { id:'style_bun', name:'Top Bun', value:'bun', cost:90, icon:'🔥' },
    { id:'style_flat', name:'Flat Top', value:'flat', cost:75, icon:'✂️' },
  ],
  hair: [
    { id:'hair_black', name:'Jet Black', value:'#121212', cost:0, swatch:'#121212' },
    { id:'hair_brown', name:'Dark Brown', value:'#3b2414', cost:0, swatch:'#3b2414' },
    { id:'hair_blonde', name:'Blonde', value:'#d9a441', cost:50, swatch:'#d9a441' },
    { id:'hair_auburn', name:'Auburn', value:'#7a3b1a', cost:50, swatch:'#7a3b1a' },
    { id:'hair_silver', name:'Silver', value:'#e6e0d8', cost:100, swatch:'#e6e0d8' },
    { id:'hair_blue', name:'Electric Blue', value:'#39a7ff', cost:130, swatch:'#39a7ff' },
    { id:'hair_pink', name:'Hot Pink', value:'#ff5bc8', cost:130, swatch:'#ff5bc8' },
  ],
  outfit: [
    { id:'outfit_blaze', name:'Blaze Classic', value:'blaze', cost:0, colors:['#ff7a1a','#b84a00','#ffe2c4','#fff6ea'] },
    { id:'outfit_tide', name:'Tide Classic', value:'tide', cost:0, colors:['#19c3b4','#0b7a72','#d3fff9','#f2fffd'] },
    { id:'outfit_purple', name:'Purple Haze', value:'purple', cost:120, colors:['#9b5cff','#54218f','#f3d9ff','#ffffff'] },
    { id:'outfit_ice', name:'Ice Breaker', value:'ice', cost:150, colors:['#65dfff','#237ca6','#e5fbff','#ffffff'] },
    { id:'outfit_gold', name:'Golden MVP', value:'gold', cost:220, colors:['#ffc52e','#a66c00','#fff0a0','#ffffff'] },
    { id:'outfit_stealth', name:'Stealth Mode', value:'stealth', cost:180, colors:['#424b5a','#202630','#bfc8d8','#ffffff'] },
  ],
};
const DEFAULT_COSMETICS = { skin:'skin_1', style:'style_fade', hair:'hair_black', outfit:'outfit_blaze' };
const cosmeticById = Object.fromEntries(Object.values(COSMETICS).flat().map(item => [item.id, item]));
function loadCosmetics(x) {
  const owned = Array.isArray(x.ownedCosmetics) ? x.ownedCosmetics.filter(id => cosmeticById[id]) : [];
  for (const item of Object.values(COSMETICS).flat()) if (item.cost === 0 && !owned.includes(item.id)) owned.push(item.id);
  const equipped = { ...DEFAULT_COSMETICS, ...(x.equippedCosmetics || {}) };
  for (const cat of Object.keys(COSMETICS)) if (!cosmeticById[equipped[cat]] || !owned.includes(equipped[cat]) || !COSMETICS[cat].some(item => item.id === equipped[cat])) equipped[cat] = DEFAULT_COSMETICS[cat];
  return { ownedCosmetics: owned, equippedCosmetics: equipped };
}

function loadWallet() {
  try {
    const x = JSON.parse(localStorage.getItem('slamHeadsWalletV1') || '{}');
    return {
      coins: Math.max(0, Number(x.coins) || 0),
      owned: Array.isArray(x.owned) ? [...new Set(['boost', ...x.owned.filter(k => SHOP_POWERS[k])])] : ['boost'],
      equipped: SHOP_POWERS[x.equipped] ? x.equipped : 'boost',
      ownedTrails: Array.isArray(x.ownedTrails) ? [...new Set(['classic', ...x.ownedTrails.filter(k => BALL_TRAILS[k])])] : ['classic'],
      equippedTrail: BALL_TRAILS[x.equippedTrail] ? x.equippedTrail : 'classic',
      ...loadCosmetics(x)
    };
  } catch { return { coins: 0, owned: ['boost'], equipped: 'boost', ownedTrails: ['classic'], equippedTrail: 'classic', ...loadCosmetics({}) }; }
}
const wallet = loadWallet();
function saveWallet() { try { localStorage.setItem('slamHeadsWalletV1', JSON.stringify(wallet)); } catch {} updateWalletUI(); }
function updateWalletUI() { const m=document.getElementById('menuCoins'), s=document.getElementById('shopCoins'), c=document.getElementById('customCoins'); if(m) m.textContent=wallet.coins; if(s) s.textContent=wallet.coins; if(c) c.textContent=wallet.coins; }
function renderShop() {
  const root=document.getElementById('shopItems'), trailRoot=document.getElementById('trailShopItems');
  if(root) {
    root.innerHTML=Object.entries(SHOP_POWERS).map(([id,p])=>{ const owned=wallet.owned.includes(id), equipped=wallet.equipped===id; const label=equipped?'EQUIPPED':owned?'EQUIP':`BUY · ${p.cost} 🪙`; const disabled=equipped || (!owned && wallet.coins<p.cost); return `<article class="shop-item"><h3>${p.icon} ${p.name}</h3><p>${p.desc}</p><button data-power="${id}" class="${equipped?'equipped':''}" ${disabled?'disabled':''}>${label}</button></article>`; }).join('');
    root.querySelectorAll('button[data-power]').forEach(btn=>btn.addEventListener('click',()=>{ const id=btn.dataset.power, p=SHOP_POWERS[id]; if(!wallet.owned.includes(id)){ if(wallet.coins<p.cost) return; wallet.coins-=p.cost; wallet.owned.push(id); Audio.crowdPop(); } wallet.equipped=id; saveWallet(); renderShop(); }));
  }
  if(trailRoot) {
    trailRoot.innerHTML=Object.entries(BALL_TRAILS).map(([id,t])=>{ const owned=wallet.ownedTrails.includes(id), equipped=wallet.equippedTrail===id; const label=equipped?'EQUIPPED':owned?'EQUIP':`BUY · ${t.cost} 🪙`; const disabled=equipped || (!owned && wallet.coins<t.cost); const swatches=t.colors.map(col=>`<i style="background:${col};box-shadow:0 0 8px ${col}"></i>`).join(''); return `<article class="shop-item trail-item"><h3>${t.icon} ${t.name}</h3><div class="trail-preview ${t.style}">${swatches}</div><p>${t.desc}</p><button data-trail="${id}" class="${equipped?'equipped':''}" ${disabled?'disabled':''}>${label}</button></article>`; }).join('');
    trailRoot.querySelectorAll('button[data-trail]').forEach(btn=>btn.addEventListener('click',()=>{ const id=btn.dataset.trail, t=BALL_TRAILS[id]; if(!wallet.ownedTrails.includes(id)){ if(wallet.coins<t.cost) return; wallet.coins-=t.cost; wallet.ownedTrails.push(id); Audio.trailEquip(); } wallet.equippedTrail=id; Audio.trailEquip(); saveWallet(); renderShop(); }));
  }
  renderCustomization();
  updateWalletUI();
}
function renderCustomization() {
  const containers = { skin:'skinShopItems', style:'hairStyleShopItems', hair:'hairColorShopItems', outfit:'outfitShopItems' };
  for (const [category, rootId] of Object.entries(containers)) {
    const root = document.getElementById(rootId); if (!root) continue;
    root.innerHTML = COSMETICS[category].map(item => {
      const owned = wallet.ownedCosmetics.includes(item.id), equipped = wallet.equippedCosmetics[category] === item.id;
      const label = equipped ? 'EQUIPPED' : owned ? 'EQUIP' : `BUY · ${item.cost} 🪙`;
      const disabled = equipped || (!owned && wallet.coins < item.cost);
      const preview = item.swatch ? `<span class="cosmetic-swatch" style="background:${item.swatch}"></span>` : item.colors ? `<span class="outfit-swatch">${item.colors.slice(0,3).map(col=>`<i style="background:${col}"></i>`).join('')}</span>` : `<span class="hair-icon">${item.icon}</span>`;
      return `<article class="shop-item cosmetic-item"><h3>${preview}${item.name}</h3><button data-cosmetic="${item.id}" data-category="${category}" class="${equipped?'equipped':''}" ${disabled?'disabled':''}>${label}</button></article>`;
    }).join('');
    root.querySelectorAll('button[data-cosmetic]').forEach(btn => btn.addEventListener('click', () => {
      const id = btn.dataset.cosmetic, category = btn.dataset.category, item = cosmeticById[id];
      if (!item) return;
      if (!wallet.ownedCosmetics.includes(id)) { if (wallet.coins < item.cost) return; wallet.coins -= item.cost; wallet.ownedCosmetics.push(id); Audio.crowdPop(); }
      wallet.equippedCosmetics[category] = id; Audio.trailEquip(); saveWallet(); renderCustomization();
    }));
  }
  updateWalletUI();
}

// ───────────────────────── online multiplayer transport ─────────────────────────
const DEFAULT_ONLINE_SERVER_URL = 'https://slam-heads-multiplayer.onrender.com';
const online = { socket: null, role: -1, roomCode: '', remoteIntent: {}, url: '', hostSnapshotTimer: 0, inputTimer: 0, lastSnapshotMode: 'menu', connected: false };
const onlinePanel = document.getElementById('onlinePanel');
const onlineStatus = document.getElementById('onlineRoomStatus');
function setOnlineStatus(message, kind='') { if (!onlineStatus) return; onlineStatus.textContent = message; onlineStatus.className = `online-status ${kind}`.trim(); }
function showOnlinePanel() { onlinePanel.classList.remove('hidden'); $('menu').classList.add('hidden'); }
function hideOnlinePanel() { onlinePanel.classList.add('hidden'); $('menu').classList.remove('hidden'); }
function updateOnlineRoomUI() {
  const inRoom = !!online.roomCode;
  $('onlineRoomCodeWrap').classList.toggle('hidden', !inRoom);
  $('onlineRoomCode').textContent = online.roomCode || '------';
  $('leaveOnlineBtn').classList.toggle('hidden', !inRoom);
  $('createRoomBtn').classList.toggle('hidden', inRoom);
  $('joinRoomBtn').classList.toggle('hidden', inRoom);
  $('startOnlineBtn').classList.toggle('hidden', !(inRoom && online.role === 0 && online.roomReady));
  if (inRoom && !online.roomReady) setOnlineStatus(`Room ${online.roomCode} created. Share the code and wait for your friend to join.`, 'good');
  else if (inRoom && online.roomReady) setOnlineStatus(`Room ${online.roomCode} is ready! Both players are connected.`, 'good');
}
function onlineError(message) { setOnlineStatus(message, 'error'); }
function currentOnlineUrl() {
  // The server address is built in so players never have to paste a URL.
  // Deploy the included Render service using the name in render.yaml.
  return DEFAULT_ONLINE_SERVER_URL;
}
function bindOnlineSocket(socket) {
  socket.on('connect', () => { online.connected = true; setOnlineStatus('Connected to the multiplayer server. Creating your private room…', 'good'); if (online.pendingAction) { const action = online.pendingAction; online.pendingAction = null; socket.emit(action.event, action.data); } });
  socket.on('connect_error', () => onlineError('Could not connect to that server. Check the URL and make sure the multiplayer server is running.'));
  socket.on('room:created', data => { online.roomCode = data.code; online.role = 0; online.roomReady = false; updateOnlineRoomUI(); });
  socket.on('room:joined', data => { online.roomCode = data.code; online.role = 1; online.roomReady = true; updateOnlineRoomUI(); socket.emit('player:look', { role: 1, look: applyEquippedLook(randomLook(new Set())) }); });
  socket.on('room:status', data => { online.roomReady = !!data.ready; if (data.players < 2) online.remoteIntent = {}; updateOnlineRoomUI(); if (data.ready) setOnlineStatus(`Room ${online.roomCode}: both players connected. Host can start the match.`, 'good'); });
  socket.on('room:error', data => onlineError(data && data.message ? data.message : 'Could not use that room.'));
  socket.on('room:closed', () => { online.roomCode = ''; online.role = -1; online.roomReady = false; if (state.cfg.mode === 'online') toMenu(); setOnlineStatus('The room was closed by the host.', 'error'); updateOnlineRoomUI(); });
  socket.on('player:input', data => { if (online.role === 0 && data && data.role === 1) online.remoteIntent = data.intent || {}; });
  socket.on('player:look', data => { if (online.role === 0 && data && data.look) online.remoteLook = data.look; });
  socket.on('game:start', data => { online.role = data.role; online.roomCode = data.code; online.roomReady = true; state.cfg.mode = 'online'; state.cfg.len = Number(data.len) || 120; startGame(); setOnlineStatus(`Match started! You are Player ${online.role + 1}.`, 'good'); });
  socket.on('game:snapshot', snap => { if (online.role !== 1 || !snap || state.cfg.mode !== 'online') return; applyOnlineSnapshot(snap); });
  socket.on('disconnect', () => { online.connected = false; if (online.roomCode) onlineError('Connection lost. Reconnect to the server or return to the menu.'); });
}
function ensureOnlineSocket(action) {
  const url = currentOnlineUrl(); if (!url) return;
  if (!window.io) { onlineError('The multiplayer connection library did not load. Refresh the page and try again.'); return; }
  if (online.socket && online.url === url && online.socket.connected) { online.socket.emit(action.event, action.data); return; }
  if (online.socket) { online.socket.removeAllListeners(); online.socket.disconnect(); }
  online.url = url; online.pendingAction = action;
  online.socket = window.io(url, { transports: ['websocket', 'polling'], timeout: 12000 });
  bindOnlineSocket(online.socket);
  setOnlineStatus('Connecting to the multiplayer server…');
}
function onlineLocalIntent() {
  if (online.role === 0) return humanIntent(0);
  return { left: !!(keys.ArrowLeft || touchState.left), right: !!(keys.ArrowRight || touchState.right), jump: !!(keys.ArrowUp || touchState.jump), shoot: !!(keys.ArrowDown || touchState.shoot), pass: !!(keys.Slash || keys.ShiftRight || touchState.pass), power: !!(keys.KeyN || touchState.power) };
}
function makeOnlineSnapshot() {
  const players = state.players.map(p => JSON.parse(JSON.stringify(p)));
  const b = state.ball;
  const ball = { ...b, owner: null, shooter: null, ownerId: b.owner ? b.owner.id : null, shooterId: b.shooter ? b.shooter.id : null, noPick: Array.from(b.noPick instanceof Map ? b.noPick.entries() : []) };
  return { mode: state.mode, phase: state.phase, phaseT: state.phaseT, players, ball, score: state.score.slice(), clock: state.clock, shotClock: state.shotClock, possTeam: state.possTeam, overtime: state.overtime, clockOut: state.clockOut, lastScorer: state.lastScorer, streak: state.streak.slice(), banner: state.banner, violTeam: state.violTeam, coinsEarned: state.coinsEarned };
}
function applyOnlineSnapshot(snap) {
  const previousMode = state.mode;
  state.phase = snap.phase; state.phaseT = snap.phaseT; state.players = snap.players;
  state.score = snap.score; state.clock = snap.clock; state.shotClock = snap.shotClock; state.possTeam = snap.possTeam;
  state.overtime = snap.overtime; state.clockOut = snap.clockOut; state.lastScorer = snap.lastScorer; state.streak = snap.streak || [0,0]; state.banner = snap.banner; state.violTeam = snap.violTeam;
  const rawBall = snap.ball || {};
  state.ball = { ...rawBall, owner: rawBall.ownerId == null ? null : state.players.find(p => p.id === rawBall.ownerId) || null, shooter: rawBall.shooterId == null ? null : state.players.find(p => p.id === rawBall.shooterId) || null, noPick: new Map(rawBall.noPick || []) };
  if (snap.mode === 'over' && previousMode !== 'over') { state.coinsAwarded = false; endGame(); }
}
function leaveOnlineRoom() {
  if (online.socket) { online.socket.emit('room:leave'); online.socket.disconnect(); online.socket = null; }
  online.roomCode = ''; online.role = -1; online.roomReady = false; online.connected = false; online.remoteIntent = {}; state.cfg.mode = '1v1'; updateOnlineRoomUI(); setOnlineStatus('You left the room.');
}

// ───────────────────────── state ─────────────────────────
const state = {
  mode: 'menu', // menu | playing | paused | over
  phase: 'attract', // tipoff | play | scored | violation | end
  cfg: { mode: '1v1', diff: 'normal', len: 120 },
  tournamentRound: 1, tournamentWon: false,
  players: [], ball: null, score: [0, 0], clock: 120, shotClock: SHOT_CLOCK, possTeam: -1,
  phaseT: 0, overtime: false, clockOut: false, particles: [], texts: [], shake: 0, t: 0,
  lastScorer: -1, streak: [0, 0], banner: null, crowdHype: 0, flash: 0, coinsAwarded: false, coinsEarned: 0,
};

function makePlayer(id, team, slot, human, look) {
  return {
    id, team, slot, human, x: 0, y: FLOOR, vx: 0, vy: 0, onGround: true, facing: team === 0 ? 1 : -1,
    st: 'normal', stT: 0, shootT: 0, meter: 0, prev: {}, intent: {}, stealCD: 0, swipeT: 0, jumpCD: 0, powerT: 0, powerCD: 0,
    run: 0, squash: 0, dunk: null, hangT: 0, stunT: 0, fire: false, celebrate: 0, label: '',
    look, name: look.name, stats: { pts: 0, fgm: 0, fga: 0, tpm: 0, tpa: 0, dunks: 0, blk: 0, stl: 0, reb: 0 },
    ai: { reactT: 0, plan: null, jukeT: 0, jukeDir: 0, releaseVy: 0, wantShot: false, thinkT: 0, offT: 0, spot: 0 },
  };
}
function randomLook(used) {
  let name; do { name = pick(NAMES); } while (used.has(name)); used.add(name);
  return { skin: pick(SKINS), hair: pick(HAIRS), style: pick(STYLES), name, num: 1 + ((Math.random() * 54) | 0), band: Math.random() < 0.5, beard: Math.random() < 0.3, headR: rand(31, 36) };
}

function applyEquippedLook(look) {
  const eq = wallet.equippedCosmetics || DEFAULT_COSMETICS;
  const skin = cosmeticById[eq.skin], style = cosmeticById[eq.style], hair = cosmeticById[eq.hair], outfit = cosmeticById[eq.outfit];
  if (skin) look.skin = skin.value;
  if (style) look.style = style.value;
  if (hair) look.hair = hair.value;
  if (outfit) look.outfit = outfit.value;
  return look;
}
function setupMatch() {
  const c = state.cfg;
  const used = new Set();
  state.players = [];
  const perTeam = c.mode === '2v2' ? 2 : 1;
  let id = 0;
  for (let team = 0; team < 2; team++) {
    for (let s = 0; s < perTeam; s++) {
      let human = -1;
      if (state.mode !== 'attract') {
        if (team === 0 && s === 0) human = 0;
        if (team === 1 && s === 0 && (c.mode === 'pvp' || c.mode === 'online')) human = 1;
      }
      const p = makePlayer(id++, team, s, human, randomLook(used));
      if (human === 0) applyEquippedLook(p.look);
      if (c.mode === 'online' && team === 1 && s === 0 && online.remoteLook) p.look = { ...p.look, ...online.remoteLook };
      p.label = human === 0 ? 'P1' : human === 1 ? 'P2' : 'CPU';
      p.powerKind = human === 0 ? wallet.equipped : 'boost';
      state.players.push(p);
    }
  }
  state.ball = { x: W / 2, y: FLOOR - 300, vx: 0, vy: 0, owner: null, spin: 0, inShot: false, shooter: null, shotTeam: -1, shotValue: 2, shotT: 0, rimTouched: false, noPick: new Map(), dribble: 0, trail: [], pass: false, lastTeam: -1, perfect: false };
  state.score = [0, 0];
  state.clock = c.len;
  state.shotClock = SHOT_CLOCK;
  state.possTeam = -1;
  state.overtime = false; state.clockOut = false; state.coinsAwarded = false;
  state.streak = [0, 0]; state.particles = []; state.texts = [];
  startTipoff();
}

function startTipoff() {
  const ps = state.players;
  for (const p of ps) {
    const side = p.team === 0 ? -1 : 1;
    p.x = W / 2 + side * (60 + p.slot * 230); p.y = FLOOR; p.vx = 0; p.vy = 0; p.onGround = true; p.st = 'normal';
    p.facing = -side; p.dunk = null;
  }
  const b = state.ball;
  b.owner = null; b.x = W / 2; b.y = FLOOR - 170; b.vx = 0; b.vy = 0; b.inShot = false; b.noPick.clear(); b.tossed = false; b.rimTouched = false; b.trail.length = 0;
  state.possTeam = -1;
  state.phase = 'tipoff'; state.phaseT = 0;
  state.banner = state.cfg.mode === 'tournament'
    ? { text: `ROUND ${state.tournamentRound} / 5`, sub: ['ROOKIE RIVALS','RISING CHALLENGER','ALL-STAR SQUAD','ELITE CONTENDERS','THE FINAL BOSS'][state.tournamentRound - 1], t: 0, dur: 1.6, color: '#ffd23f' }
    : { text: 'TIP OFF', sub: '', t: 0, dur: 1.1, color: '#ffd23f' };
}

function resetPossession(team) {
  // team gets the ball in its own backcourt
  const ps = state.players;
  const myHoop = defendHoop(team), dir = -myHoop.dir; // dir toward attack
  let k = 0, j = 0;
  for (const p of ps) {
    p.vx = 0; p.vy = 0; p.y = FLOOR; p.onGround = true; p.st = 'normal'; p.dunk = null; p.stunT = 0;
    if (p.team === team) { p.x = myHoop.cx + dir * (230 + k * 150); k++; }
    else { p.x = myHoop.cx + dir * (470 + j * 120); j++; }
    p.facing = p.team === team ? dir : -dir;
  }
  const carrier = ps.find((p) => p.team === team && p.slot === 0);
  giveBall(carrier);
  state.shotClock = SHOT_CLOCK; state.possTeam = team;
}

function giveBall(p) {
  const b = state.ball;
  b.owner = p; b.inShot = false; b.pass = false; b.shooter = null; b.vx = 0; b.vy = 0; b.lastTeam = p.team;
  b.noPick.clear();
  p.ai.plan = null; p.safeT = 0.7;
  if (state.possTeam !== p.team || b.rimTouched) { state.shotClock = SHOT_CLOCK; }
  b.rimTouched = false;
  state.possTeam = p.team;
}

// ───────────────────────── fx ─────────────────────────
function burst(x, y, n, colors, spd = 300, life = 0.7, grav = 900, size = 4) {
  for (let i = 0; i < n; i++) {
    const a = rand(0, Math.PI * 2), s = rand(0.3, 1) * spd;
    state.particles.push({ x, y, vx: Math.cos(a) * s, vy: Math.sin(a) * s - spd * 0.3, life, max: life, c: pick(colors), g: grav, s: rand(size * 0.5, size * 1.3) });
  }
}
function dust(x, y, n = 6) {
  for (let i = 0; i < n; i++) state.particles.push({ x: x + rand(-14, 14), y, vx: rand(-90, 90), vy: rand(-80, -20), life: 0.45, max: 0.45, c: 'rgba(230,200,160,0.55)', g: 120, s: rand(3, 6), round: true });
}
function popText(x, y, text, color = '#ffd23f', size = 30) { state.texts.push({ x, y, text, color, size, t: 0, dur: 1.1 }); }
function banner(text, sub = '', color = '#ffd23f', dur = 1.4) { state.banner = { text, sub, t: 0, dur, color }; }
function ringBurst(x, y, color = '#ffd23f', maxR = 100, life = 0.42) {
  state.particles.push({ x, y, vx: 0, vy: 0, life, max: life, c: color, g: 0, s: maxR, ring: true, glow: true });
}
function sparkShower(x, y, n = 18, colors = ['#fff4c2', '#ffd23f', '#ff7a1a']) {
  burst(x, y, n, colors, 420, 0.58, 620, 4.5);
  ringBurst(x, y, pick(colors), 115, 0.38);
}

// ───────────────────────── shooting math ─────────────────────────
function simulateShotX(x, y, vx, vy, ty) {
  // integrate exactly like the live sim (ignoring collisions); return x when crossing ty descending
  const dt = 1 / 240;
  let px = x, py = y, pvy = vy;
  for (let i = 0; i < 2400; i++) {
    pvy += G_BALL * dt; px += vx * dt; py += pvy * dt;
    if (pvy > 0 && py >= ty) return px;
  }
  return px;
}
function solveShot(x, y, tx, ty) {
  const dx = tx - x, adx = Math.abs(dx), dirx = sign(dx);
  const rise = y - ty; // positive if target above
  let theta = (adx < 220 ? 62 : adx < 500 ? 55 : 50) * Math.PI / 180;
  // ensure feasible
  while (adx * Math.tan(theta) - rise <= 10 && theta < 1.45) theta += 0.05;
  let v = Math.sqrt((G_BALL * adx * adx) / (2 * Math.cos(theta) ** 2 * (adx * Math.tan(theta) - rise)));
  // refine speed with secant iterations against the discrete integrator
  for (let i = 0; i < 6; i++) {
    const land = simulateShotX(x, y, dirx * v * Math.cos(theta), -v * Math.sin(theta), ty);
    const err = (land - tx) * dirx;
    if (Math.abs(err) < 0.5) break;
    const v2 = v * 1.01;
    const land2 = simulateShotX(x, y, dirx * v2 * Math.cos(theta), -v2 * Math.sin(theta), ty);
    const d = ((land2 - land) * dirx) / (v2 - v);
    if (Math.abs(d) < 1e-6) break;
    v -= err / d;
  }
  return { vx: dirx * v * Math.cos(theta), vy: -v * Math.sin(theta) };
}

function nearestOpponent(p) {
  let best = null, bd = 1e9;
  for (const q of state.players) if (q.team !== p.team) { const d = Math.abs(q.x - p.x); if (d < bd) { bd = d; best = q; } }
  return best;
}

function releaseShot(p) {
  const b = state.ball;
  const hoop = attackHoop(p.team);
  const dist = Math.abs(hoop.cx - p.x);
  // timing: ideal release at apex (vy ~ 0)
  const timing = p.vy / SHOT_JUMP_V; // -1 at takeoff, 0 apex, + falling
  const e = Math.abs(timing);
  const greenW = p.fire ? 0.2 : 0.12;
  const perfect = e <= greenW;
  // contest
  let contest = 0;
  for (const q of state.players) {
    if (q.team === p.team) continue;
    const dx = Math.abs(q.x - p.x);
    const between = sign(hoop.cx - p.x) === sign(q.x - p.x);
    if (dx < 110) contest = Math.max(contest, (1 - dx / 110) * (between ? 1 : 0.5) * (q.onGround ? 0.6 : 1));
  }
  let miss = 0;
  if (perfect) miss = gauss() * (3 + contest * 10);
  else {
    const dirMiss = timing < 0 ? -1 : 1; // early -> short, late -> long
    miss = dirMiss * (e - greenW) * 120 + gauss() * (6 + dist / 110);
    miss += gauss() * contest * 22;
  }
  if (p.fire) miss *= 0.6;
  const rx = p.x + p.facing * 8, ry = p.y - 168;
  const sol = solveShot(rx, ry, hoop.cx + sign(hoop.cx - rx) * miss, RIM_Y - 2);
  b.owner = null; b.x = rx; b.y = ry; b.vx = sol.vx; b.vy = sol.vy;
  b.inShot = true; b.shooter = p; b.shotTeam = p.team; b.shotT = 0; b.rimTouched = false; b.pass = false; b.perfect = perfect;
  b.shotValue = dist >= THREE_DIST ? 3 : 2; b.lastTeam = p.team;
  b.noPick.set(p.id, 0.35);
  b.spin = -sign(sol.vx) * 14;
  p.stats.fga++; if (b.shotValue === 3) p.stats.tpa++;
  p.st = 'release'; p.stT = 0;
  Audio.whoosh();
  burst(b.x, b.y, 8, perfect ? ['#7dff6b', '#ffffff', '#ffd23f'] : ['#fff1bf', '#ffffff'], 150, 0.28, 160, 2.5);
  if (perfect) { Audio.green(); popText(p.x, p.y - 220, p.fire ? 'ON FIRE' : 'GREEN', '#7dff6b', 22); }
  else popText(p.x, p.y - 220, timing < 0 ? 'EARLY' : 'LATE', '#ffb3a0', 18);
}

function startDunk(p) {
  const hoop = attackHoop(p.team);
  const endX = hoop.cx - hoop.dir * 8;
  p.st = 'dunk'; p.stT = 0;
  p.dunk = { sx: p.x, sy: p.y, ex: endX, ey: RIM_Y + 128, dur: clamp(Math.abs(endX - p.x) / 700, 0.28, 0.5), hoop, style: (Math.random() * 3) | 0 };
  p.facing = hoop.dir;
  p.stats.fga++;
  Audio.whoosh();
  Audio.crowdPop();
  sparkShower(p.x, p.y - 85, 12, [TEAMS[p.team].main, TEAMS[p.team].trim, '#ffffff']);
}

function startPass(p) {
  const mate = state.players.find((q) => q.team === p.team && q !== p);
  if (!mate) return;
  const b = state.ball;
  const tx = mate.x + mate.vx * 0.25, ty = mate.y - 90;
  const sx = p.x + p.facing * 20, sy = p.y - 95;
  const dist = Math.hypot(tx - sx, ty - sy);
  const t = clamp(dist / 900, 0.25, 0.9);
  b.owner = null; b.x = sx; b.y = sy; b.vx = (tx - sx) / t; b.vy = (ty - sy - 0.5 * G_BALL * t * t) / t;
  b.inShot = false; b.pass = true; b.lastTeam = p.team; b.noPick.set(p.id, 0.3);
  p.facing = sign(tx - sx); p.st = 'pass'; p.stT = 0;
  Audio.whoosh();
}

// ───────────────────────── player update ─────────────────────────
function updatePlayer(p, dt) {
  const b = state.ball;
  const I = p.intent, P = p.prev;
  const pressed = (k) => I[k] && !P[k];
  const released = (k) => !I[k] && P[k];
  const hasBall = b.owner === p;
  const canAct = state.phase === 'play' || state.phase === 'tipoff';
  const spd = RUN_SPEED * (p.human < 0 ? getDiff().speed : 1) * (hasBall ? 0.94 : 1) * (p.fire ? 1.06 : 1) * (p.powerT > 0 ? (p.powerKind === 'speed' ? 1.45 : p.powerKind === 'boost' ? 1.24 : p.powerKind === 'sniper' ? 1.12 : 1.05) : 1);

  p.stealCD = Math.max(0, p.stealCD - dt);
  p.powerCD = Math.max(0, p.powerCD - dt);
  p.powerT = Math.max(0, p.powerT - dt);
  const powerPressed = I.power && !P.power;
  if (canAct && state.phase === 'play' && powerPressed && p.powerCD <= 0) {
    p.powerT = p.powerKind === 'sniper' ? 5 : 3; p.powerCD = 10;
    Audio.cheer(0.45); Audio.impact();
    sparkShower(p.x, p.y - 90, 22, ['#ffd23f', '#19c3b4', '#ffffff', TEAMS[p.team].main]);
    ringBurst(p.x, p.y - 70, '#ffd23f', 100, 0.38);
    popText(p.x, p.y - 190, (p.powerKind === 'speed' ? 'TURBO!' : p.powerKind === 'jump' ? 'SKY WALKER!' : p.powerKind === 'steal' ? 'LOCKDOWN!' : p.powerKind === 'sniper' ? 'GREEN MACHINE!' : 'POWER UP!'), '#ffd23f', 24);
    state.flash = Math.max(state.flash, 0.08);
  }
  P.power = I.power;
  p.safeT = Math.max(0, (p.safeT || 0) - dt);
  p.swipeT = Math.max(0, p.swipeT - dt);
  p.jumpCD = Math.max(0, p.jumpCD - dt);
  p.squash = Math.max(0, p.squash - dt * 5);
  p.celebrate = Math.max(0, p.celebrate - dt);
  p.stT += dt;

  if (p.st === 'dunk') {
    const d = p.dunk; const t = clamp(p.stT / d.dur, 0, 1);
    const e = t < 0.5 ? 2 * t * t : 1 - Math.pow(-2 * t + 2, 2) / 2;
    p.x = lerp(d.sx, d.ex, e);
    const arcTop = Math.min(d.sy, d.ey) - 70;
    p.y = (1 - t) * (1 - t) * d.sy + 2 * (1 - t) * t * arcTop + t * t * d.ey;
    // ball in hands overhead
    if (b.owner === p) { b.x = p.x + p.facing * (14 + t * 10); b.y = p.y - 178 - Math.sin(t * Math.PI) * 18; }
    // dunk block check
    for (const q of state.players) {
      if (q.team === p.team || q.onGround || b.owner !== p) continue;
      const hx = q.x, hy = q.y - 170;
      if (Math.hypot(hx - b.x, hy - b.y) < 46 && Math.random() < 0.7) {
        blockBall(q, p);
        p.st = 'normal'; p.vy = 100; p.vx = -p.facing * 120; p.onGround = false; p.dunk = null;
        return;
      }
    }
    if (t >= 1 && b.owner === p) {
      // SLAM
      b.owner = null; b.x = d.hoop.cx; b.y = RIM_Y - 18; b.vx = 0; b.vy = 900; b.inShot = true; b.shooter = p; b.shotTeam = p.team; b.shotT = 1; b.shotValue = 2; b.dunked = true; b.noPick.set(p.id, 0.5); b.lastTeam = p.team;
      d.hoop.shake = 1; d.hoop.net = 1;
      state.shake = 0.5; state.flash = 0.25;
      Audio.dunk();
      sparkShower(d.hoop.cx, RIM_Y + 4, 42, ['#ffd23f', '#ff7a1a', '#ffffff', TEAMS[p.team].main]);
      ringBurst(d.hoop.cx, RIM_Y + 4, '#ffffff', 150, 0.5);
      Audio.impact();
      p.st = 'hang'; p.stT = 0; p.hangT = 0.42; p.vx = 0; p.vy = 0;
    } else if (t >= 1) { p.st = 'normal'; p.dunk = null; }
    P.left = I.left; P.right = I.right; P.jump = I.jump; P.shoot = I.shoot; P.pass = I.pass;
    return;
  }
  if (p.st === 'hang') {
    const h = p.dunk.hoop;
    p.x = h.cx - h.dir * 8 + Math.sin(p.stT * 30) * (1 - p.stT / p.hangT) * 3; p.y = RIM_Y + 128;
    if (p.stT >= p.hangT) { p.st = 'normal'; p.dunk = null; p.onGround = false; p.vy = 0; p.vx = -h.dir * 60; }
    P.left = I.left; P.right = I.right; P.jump = I.jump; P.shoot = I.shoot; P.pass = I.pass;
    return;
  }

  // horizontal movement
  let mx = 0;
  if (canAct && p.stunT <= 0) { if (I.left) mx -= 1; if (I.right) mx += 1; }
  p.stunT = Math.max(0, p.stunT - dt);
  const shooting = p.st === 'shoot';
  const target = mx * spd * (shooting && p.onGround ? 0 : 1);
  const accel = p.onGround ? 14 : 4.5;
  const prevVx = p.vx;
  p.vx += (target - p.vx) * Math.min(1, dt * accel);
  if (mx !== 0 && !shooting) {
    if (p.onGround && sign(mx) !== sign(prevVx) && Math.abs(prevVx) > 220) { Audio.squeak(); dust(p.x, FLOOR, 3); }
    p.facing = mx;
  }
  if (Math.abs(p.vx) > 30 && p.onGround) p.run += dt * Math.abs(p.vx) / 38;

  // jump
  if (canAct && pressed('jump') && p.onGround && p.jumpCD <= 0 && p.st !== 'shoot') {
    p.vy = -JUMP_V * (p.fire ? 1.1 : 1) * (p.powerT > 0 ? (p.powerKind === 'jump' ? 1.62 : p.powerKind === 'boost' ? 1.18 : 1.04) : 1); p.onGround = false; p.jumpCD = 0.12; Audio.jump(); dust(p.x, FLOOR, 5);
  }

  // shoot / action
  if (canAct && state.phase === 'play') {
    if (hasBall) {
      const hoop = attackHoop(p.team);
      const dHoop = Math.abs(hoop.cx - p.x);
      const towardHoop = sign(hoop.cx - p.x);
      if (pressed('shoot') && p.st === 'normal') {
        const highEnough = p.y < FLOOR - 40;
        if ((!p.onGround && dHoop < 290 && highEnough) || (p.onGround && dHoop < 175)) {
          if (p.onGround) { p.vy = -JUMP_V; p.onGround = false; }
          startDunk(p);
        } else {
          p.st = 'shoot'; p.stT = 0; p.facing = towardHoop;
          if (p.onGround) { p.vy = -SHOT_JUMP_V * (p.fire ? 1.05 : 1) * (p.powerT > 0 ? (p.powerKind === 'jump' ? 1.42 : p.powerKind === 'boost' ? 1.12 : 1.02) : 1); p.onGround = false; dust(p.x, FLOOR, 4); }
          else if (p.vy < -SHOT_JUMP_V) p.vy = -SHOT_JUMP_V;
          Audio.meter();
        }
      } else if (pressed('pass') && p.st === 'normal' && state.players.length > 2) {
        startPass(p);
      }
      if (p.st === 'shoot') {
        p.facing = towardHoop;
        if (released('shoot') || !I.shoot) releaseShot(p);
      }
    } else if (pressed('shoot') && p.stealCD <= 0) {
      // steal swipe
      p.swipeT = 0.22; p.stealCD = 0.65; Audio.whoosh();
      const h = b.owner;
      if (h && h.team !== p.team && h.st !== 'dunk' && h.st !== 'hang' && !(h.safeT > 0)) {
        const dx = h.x - p.x, dy = Math.abs(h.y - p.y);
        if (Math.abs(dx) < 78 && dy < 70) {
          const facingIt = sign(dx) === p.facing ? 1 : 0.55;
          let chance = 0.38 * facingIt * (p.powerT > 0 ? (p.powerKind === 'steal' ? 2.15 : p.powerKind === 'boost' ? 1.35 : 1.05) : 1);
          if (h.st === 'shoot') chance = 0.18;
          if (!h.onGround) chance *= 0.6;
          if (Math.random() < chance) {
            giveBall(p); p.stats.stl++;
            Audio.steal(); popText(p.x, p.y - 210, 'STOLEN', '#ffd23f', 26);
            h.stunT = 0.35; h.vx = -sign(dx) * -150;
            burst(p.x, p.y - 80, 10, ['#ffffff', '#ffd23f'], 220, 0.4, 400, 3);
            state.crowdHype = 0.6;
          }
        }
      }
    }
  }

  // physics
  if (!p.onGround || p.vy < 0) {
    p.vy += G_PLAYER * dt * (p.st === 'shoot' && Math.abs(p.vy) < 180 ? 0.55 : 1); // slight hang time at apex while shooting
    p.y += p.vy * dt;
  }
  p.x += p.vx * dt;
  if (p.y >= FLOOR) {
    if (!p.onGround) { p.squash = 1; if (p.vy > 600) dust(p.x, FLOOR, 4); }
    p.y = FLOOR; p.vy = 0; p.onGround = true;
    if (p.st === 'shoot' && b.owner === p) releaseShot(p); // forced release on landing
    if (p.st === 'release' || p.st === 'pass') p.st = 'normal';
  } else p.onGround = false;
  if (p.st === 'shoot' && b.owner !== p) p.st = 'normal';
  if (p.st === 'release' && p.stT > 0.45) p.st = 'normal';
  if (p.st === 'pass' && p.stT > 0.25) p.st = 'normal';
  p.x = clamp(p.x, 30, W - 30);

  // carry ball
  if (b.owner === p && p.st !== 'dunk') {
    if (p.st === 'shoot') {
      b.x = p.x + p.facing * 8; b.y = p.y - 170;
    } else if (!p.onGround) {
      b.x = p.x + p.facing * 22; b.y = p.y - 112;
    } else {
      b.dribble += dt * (6 + Math.abs(p.vx) / 70);
      const ph = Math.abs(Math.sin(b.dribble));
      b.x = p.x + p.facing * 30; b.y = lerp(FLOOR - BALL_R, p.y - 66, ph);
      if (ph < 0.12 && !b._bounced) { b._bounced = true; Audio.bounce(0.4); }
      if (ph > 0.5) b._bounced = false;
    }
  }

  P.left = I.left; P.right = I.right; P.jump = I.jump; P.shoot = I.shoot; P.pass = I.pass;
}

function blockBall(q, shooter) {
  const b = state.ball;
  b.owner = null; b.inShot = false; b.pass = false; b.dunked = false;
  b.vx = q.facing * 260 + rand(-60, 60) + q.vx * 0.3; b.vy = -rand(260, 420);
  if (Math.abs(b.vx) < 120) b.vx = sign(b.vx) * 160;
  b.noPick.set(shooter.id, 0.45);
  q.stats.blk++;
  Audio.block(); popText(q.x, q.y - 230, 'REJECTED', '#ff5a5a', 30);
  burst(b.x, b.y, 14, ['#ffffff', '#ff5a5a', '#ffd23f'], 300, 0.5, 600, 3);
  state.shake = 0.3; state.crowdHype = 0.8;
  Audio.cheer(0.7);
}

// ───────────────────────── AI ─────────────────────────
function aiThink(p, dt) {
  const D = getDiff();
  const b = state.ball, A = p.ai;
  const I = { left: false, right: false, jump: false, shoot: p.intent.shoot && p.st === 'shoot', pass: false, power: false };
  const hoop = attackHoop(p.team), myHoop = defendHoop(p.team);
  const toHoop = sign(hoop.cx - p.x);
  const moveTo = (tx, dead = 10) => { if (tx < p.x - dead) I.left = true; else if (tx > p.x + dead) I.right = true; };

  if (state.phase === 'tipoff') {
    moveTo(W / 2 + (p.team === 0 ? -30 : 30), 6);
    if (b.vy > -50 && b.y < FLOOR - 230 && Math.abs(b.x - p.x) < 90 && Math.random() < 0.25 + D.iq * 0.3) I.jump = true;
    p.intent = I; return;
  }
  if (state.phase !== 'play') { p.intent = I; return; }

  if (b.owner === p) {
    const dist = Math.abs(hoop.cx - p.x);
    const opp = nearestOpponent(p);
    if (!A.plan) {
      const r = Math.random();
      A.plan = r < 0.42 ? { type: 'drive', d: 0 } : r < 0.72 ? { type: 'mid', d: rand(250, 420) } : { type: 'three', d: rand(THREE_DIST + 15, THREE_DIST + 90) };
      A.offT = 0; A.wantShot = false; A.jukeT = 0;
    }
    A.offT += dt;
    const oppBetween = opp && sign(opp.x - p.x) === toHoop && Math.abs(opp.x - p.x) < 95;
    if (p.st === 'shoot') {
      // release near apex with error
      if (p.vy >= A.releaseVy) I.shoot = false; else I.shoot = true;
    } else {
      // juke defenders
      if (A.jukeT > 0) { A.jukeT -= dt; if (A.jukeDir < 0) { if (toHoop > 0) I.left = true; else I.right = true; } else { if (toHoop > 0) I.right = true; else I.left = true; } }
      else if (oppBetween && Math.random() < dt * 1.6 * D.iq) { A.jukeT = rand(0.18, 0.4); A.jukeDir = -1; }
      else { if (toHoop > 0) I.right = true; else I.left = true; }

      // pass in 2v2 when blocked
      const mate = state.players.find((q) => q.team === p.team && q !== p);
      if (mate && oppBetween && A.offT > 0.8 && Math.random() < dt * 0.9 && p.onGround) {
        const mateOpen = state.players.every((q) => q.team === p.team || Math.abs(q.x - mate.x) > 90);
        if (mateOpen) { I.pass = true; }
      }
      const shotClockLow = state.shotClock < 2.4;
      const clockLow = state.clock < 2.2 && !state.overtime;
      if (A.plan.type === 'drive') {
        if (dist < 300 && dist > 180 && p.onGround && !oppBetween && Math.random() < 0.35) I.jump = true;
        if (!p.onGround && dist < 285 && p.y < FLOOR - 60) I.shoot = true;
        if (dist < 170 && p.onGround) I.shoot = true;
        if (oppBetween && dist < 300 && A.offT > 1.4 && p.onGround) { A.plan = { type: 'mid', d: dist + 5 }; }
      } else if ((dist <= A.plan.d || shotClockLow || clockLow) && p.onGround) {
        if (!oppBetween || Math.random() < dt * 2 || shotClockLow || clockLow) I.shoot = true;
      }
      if ((shotClockLow || A.offT > 3.2) && p.onGround && !I.shoot) I.shoot = true;
      if (I.shoot && p.st === 'normal') A.releaseVy = gauss() * D.timing * SHOT_JUMP_V - 15;
    }
  } else if (b.owner && b.owner.team === p.team) {
    // off-ball offense (2v2): spot up on a wing or cut
    const mate = b.owner;
    const spotD = A.spot ? 520 : 300;
    if (Math.random() < dt * 0.25) A.spot = 1 - A.spot;
    let tx = hoop.cx - hoop.dir * spotD;
    if (Math.abs(tx - mate.x) < 120) tx = hoop.cx - hoop.dir * (spotD === 300 ? 520 : 300);
    moveTo(tx, 20);
  } else if (b.owner) {
    // defense
    const h = state.players.length > 2 ? (state.players.find((q) => q.team !== p.team && q.slot === p.slot) || b.owner) : b.owner;
    const guard = h === b.owner || (Math.abs(b.owner.x - p.x) < 70 && Math.abs(h.x - p.x) > 260) ? b.owner : h;
    const gap = guard === b.owner ? 76 : 120;
    const tx = guard.x + myHoop.dir * gap * 1; // stand between man and my hoop
    moveTo(tx, 8);
    if (guard === b.owner) {
      const dx = Math.abs(guard.x - p.x);
      if ((guard.st === 'shoot' || guard.st === 'dunk') && dx < 150) {
        if (A.blockT == null) { A.blockT = D.react * rand(0.6, 1.3); A.blockGo = Math.random() < D.block; }
        else { A.blockT -= dt; if (A.blockT <= 0 && A.blockGo && p.onGround) { I.jump = true; A.blockGo = false; } }
      } else if (guard.st !== 'shoot' && guard.st !== 'dunk') A.blockT = null;
      if (dx < 75 && guard.st === 'normal' && Math.random() < dt * D.steal) I.shoot = true;
      if (guard.onGround === false && guard.y < FLOOR - 60 && Math.abs(attackHoop(guard.team).cx - guard.x) < 300 && dx < 140 && p.onGround && Math.random() < dt * 6 * D.block) I.jump = true;
    }
  } else {
    // loose ball
    const mates = state.players.filter((q) => q.team === p.team);
    const chaser = mates.reduce((a, q) => (Math.abs(q.x - b.x) < Math.abs(a.x - b.x) ? q : a), mates[0]);
    if (chaser === p || mates.length === 1) {
      // predict landing a bit
      let tx = b.x + b.vx * 0.25;
      if (b.inShot && b.shotTeam !== p.team) tx = lerp(b.x, defendHoop(p.team).cx - defendHoop(p.team).dir * 60, 0.5);
      if (b.inShot && b.shotTeam === p.team) tx = lerp(b.x, hoop.cx - hoop.dir * 70, 0.5);
      moveTo(tx, 8);
      const dx = Math.abs(b.x - p.x);
      const above = p.y - 150 - b.y;
      if (p.onGround && dx < 70 && above > 30 && above < 230 && (b.vy > -150) && Math.random() < 0.5) I.jump = true;
      // contest shots in the air
      if (b.inShot && b.shotTeam !== p.team && b.shotT < 0.3 && dx < 100 && p.onGround && Math.random() < D.block * 0.08) I.jump = true;
    } else {
      moveTo(myHoop.cx - myHoop.dir * 240, 20);
    }
  }
  p.intent = I;
}

// ───────────────────────── ball update ─────────────────────────
function updateBall(dt) {
  const b = state.ball;
  for (const [k, v] of b.noPick) { if (v - dt <= 0) b.noPick.delete(k); else b.noPick.set(k, v - dt); }
  if (b.owner) { b.trail.length = 0; return; }
  if (state.phase === 'tipoff' && state.phaseT < 0.7) { b.x = W / 2; b.y = FLOOR - 170; return; }
  if (state.phase === 'tipoff' && !b.tossed) { b.tossed = true; b.vy = -820; b.vx = 0; Audio.whistle(); }
  b.shotT += dt;
  const sub = 4, h = dt / sub;
  for (let s = 0; s < sub; s++) {
    const py = b.y;
    b.vy += G_BALL * h;
    b.x += b.vx * h; b.y += b.vy * h;
    // floor
    if (b.y > FLOOR - BALL_R) {
      b.y = FLOOR - BALL_R;
      if (b.vy > 60) { Audio.bounce(clamp(b.vy / 900, 0.15, 1)); }
      b.vy = -b.vy * 0.72; b.vx *= 0.86; b.spin *= 0.8;
      if (Math.abs(b.vy) < 70) b.vy = 0;
      if (b.inShot) { b.inShot = false; } // missed shot on floor
      b.pass = false; b.dunked = false;
    }
    // walls & ceiling
    if (b.x < BALL_R) { b.x = BALL_R; b.vx = Math.abs(b.vx) * 0.6; }
    if (b.x > W - BALL_R) { b.x = W - BALL_R; b.vx = -Math.abs(b.vx) * 0.6; }
    if (b.y < 30) { b.y = 30; b.vy = Math.abs(b.vy) * 0.4; }
    for (const hp of HOOPS) {
      // backboard (vertical segment)
      const bTop = RIM_Y - 112, bBot = RIM_Y + 18;
      if (b.y > bTop - BALL_R && b.y < bBot + BALL_R) {
        const inner = hp.boardX - hp.dir * 0; // board face
        if (hp.dir > 0 && b.x + BALL_R > inner && b.x < inner + 10 && b.vx > 0) { b.x = inner - BALL_R; b.vx = -b.vx * 0.62; Audio.board(); hp.shake = 0.3; b.rimTouched = true; }
        if (hp.dir < 0 && b.x - BALL_R < inner && b.x > inner - 10 && b.vx < 0) { b.x = inner + BALL_R; b.vx = -b.vx * 0.62; Audio.board(); hp.shake = 0.3; b.rimTouched = true; }
      }
      // rim points
      for (const rx of [hp.frontX, hp.backX]) {
        const dx = b.x - rx, dy = b.y - RIM_Y, d = Math.hypot(dx, dy), minD = BALL_R + 4;
        if (d < minD && d > 0.001) {
          const nx = dx / d, ny = dy / d;
          b.x = rx + nx * minD; b.y = RIM_Y + ny * minD;
          const vn = b.vx * nx + b.vy * ny;
          if (vn < 0) {
            b.vx -= 1.55 * vn * nx; b.vy -= 1.55 * vn * ny;
            b.vx *= 0.92; b.vy *= 0.92;
            if (Math.abs(vn) > 80) { Audio.rim(clamp(Math.abs(vn) / 700, 0.2, 1)); hp.shake = Math.min(1, hp.shake + 0.35); }
            b.rimTouched = true;
          }
        }
      }
      // scoring: passes downward through rim plane between the rim points
      if (py < RIM_Y && b.y >= RIM_Y && b.vy > 0 && b.x > hp.minX + 3 && b.x < hp.maxX - 3) {
        scoreBasket(hp);
      }
    }
  }
  b.spin *= 0.995;
  b.trail.push({ x: b.x, y: b.y }); if (b.trail.length > 10) b.trail.shift();

  // pickups
  if (state.phase !== 'play' && state.phase !== 'tipoff') return;
  for (const p of state.players) {
    if (b.owner) break;
    if (b.noPick.has(p.id) || p.st === 'dunk' || p.st === 'hang') continue;
    if (state.phase === 'tipoff' && (b.vy < 0 || b.y > FLOOR - 120) && state.phaseT < 3) {
      // tip: only jumping players can tap it
      if (p.onGround) continue;
    }
    if (b.inShot && b.shotT < 0.3 && p.onGround && p.team !== b.shotTeam) continue;
    if (b.inShot && b.shotTeam === p.team && b.shotT < 0.6) continue; // can't catch own team's shot instantly
    const top = p.y - (p.onGround ? 168 : 188), bot = p.y - 10;
    const nx = clamp(b.x, p.x - 30, p.x + 30), ny = clamp(b.y, top, bot);
    if (Math.hypot(b.x - nx, b.y - ny) < BALL_R + 2) {
      // block a live shot on its way up
      if (b.inShot && b.shotTeam !== p.team && !p.onGround && b.shotT < 0.45 && b.vy < 0 && b.y < p.y - 130 && !b.rimTouched) { blockBall(p, b.shooter); continue; }
      if (state.phase === 'tipoff') {
        // tip toward own attack direction to a teammate (or self)
        state.phase = 'play'; state.phaseT = 0;
        banner('', '', '#fff', 0.01);
      }
      const wasShot = b.inShot || b.rimTouched;
      giveBall(p);
      if (wasShot) { p.stats.reb++; }
      Audio.bounce(0.3);
    }
  }
}

function scoreBasket(hp) {
  const b = state.ball;
  const team = hp.id === 1 ? 0 : 1;
  if (state.phase !== 'play' && !(state.phase === 'end' && state.clockOut)) return;
  const pts = b.inShot && b.shotTeam === team ? b.shotValue : 2;
  state.score[team] += pts;
  const shooter = b.inShot && b.shooter && b.shooter.team === team ? b.shooter : null;
  hp.net = 1;
  const clean = !b.rimTouched && !b.dunked;
  if (b.dunked) { banner(pick(['SLAM!', 'POSTERIZED!', 'BOOM!', 'JAM!']), shooter ? shooter.name : '', TEAMS[team].main); state.crowdHype = 1.4; Audio.cheer(1.3); }
  else if (pts === 3) { banner('SPLASH! +3', shooter ? shooter.name : '', TEAMS[team].main); Audio.swish(); state.crowdHype = 1.1; Audio.cheer(1); }
  else { if (clean) Audio.swish(); popText(hp.cx, RIM_Y - 70, clean ? 'SWISH +2' : '+2', TEAMS[team].main, 30); state.crowdHype = 0.7; Audio.cheer(0.6); }
  if (shooter) {
    shooter.stats.pts += pts; shooter.stats.fgm++; if (pts === 3) shooter.stats.tpm++; if (b.dunked) shooter.stats.dunks++;
    shooter.celebrate = 1.2;
  }
  // streak / on fire
  state.streak[team]++; state.streak[1 - team] = 0;
  for (const p of state.players) {
    if (p.team !== team && p.fire) { p.fire = false; }
  }
  if (shooter && state.streak[team] >= 3 && !shooter.fire) { shooter.fire = true; setTimeout(() => banner("HE'S ON FIRE", shooter.name, '#ff5a1a', 1.6), 700); }
  sparkShower(hp.cx, RIM_Y + 36, b.dunked ? 36 : 24, [TEAMS[team].main, TEAMS[team].trim, '#ffd23f', '#ffffff']);
  state.shake = Math.max(state.shake, b.dunked ? 0.42 : 0.16);
  if (clean && !b.dunked) Audio.crowdPop();
  b.inShot = false; b.dunked = false;
  state.lastScorer = team;
  if (state.overtime) { state.phase = 'end'; state.phaseT = 0; Audio.buzzer(); return; }
  if (state.clockOut) { state.phase = 'end'; state.phaseT = 0; return; }
  state.phase = 'scored'; state.phaseT = 0;
}

// Keep the mobile action button and power-up cooldown in sync with possession.
function updateTouchActionUI() {
  const actionBtn = document.querySelector('#touch [data-k="shoot"]');
  const powerBtn = document.querySelector('#touch [data-k="power"]');
  const human = state.players.find((p) => p.human === 0);
  if (actionBtn) {
    const onDefense = !!(human && state.ball && state.ball.owner && state.ball.owner.team !== human.team);
    actionBtn.textContent = onDefense ? 'STEAL' : 'SHOOT';
    actionBtn.setAttribute('aria-label', onDefense ? 'Steal the ball' : 'Shoot the ball');
    actionBtn.classList.toggle('defense', onDefense);
  }
  if (powerBtn) {
    const cd = human ? human.powerCD : 0;
    powerBtn.textContent = cd > 0 ? `${Math.ceil(cd)}s` : (human && human.powerT > 0 ? 'BOOST!' : 'POWER');
    powerBtn.disabled = !!(human && cd > 0);
    powerBtn.classList.toggle('ready', !!human && cd <= 0);
    powerBtn.classList.toggle('active', !!human && human.powerT > 0);
  }
}

// ───────────────────────── main update ─────────────────────────
function update(dt) {
  state.t += dt;
  updateTouchActionUI();
  state.shake = Math.max(0, state.shake - dt);
  state.flash = Math.max(0, state.flash - dt);
  state.crowdHype = Math.max(0, state.crowdHype - dt * 0.5);
  for (const h of HOOPS) { h.net = Math.max(0, h.net - dt * 1.8); h.shake = Math.max(0, h.shake - dt * 2.5); }
  if (state.banner) { state.banner.t += dt; if (state.banner.t > state.banner.dur) state.banner = null; }
  for (const t of state.texts) t.t += dt;
  state.texts = state.texts.filter((t) => t.t < t.dur);
  for (const q of state.particles) { q.life -= dt; q.vy += q.g * dt; q.x += q.vx * dt; q.y += q.vy * dt; }
  state.particles = state.particles.filter((q) => q.life > 0);
  if (state.mode === 'paused' || state.mode === 'over') return;
  state.phaseT += dt;

  // intents
  for (const p of state.players) {
    if (p.human >= 0 && state.mode === 'playing') {
      if (state.cfg.mode === 'online' && p.human === 1) p.intent = online.remoteIntent;
      else p.intent = humanIntent(p.human);
    } else aiThink(p, dt);
  }
  for (const p of state.players) updatePlayer(p, dt);
  // soft body separation
  const ps = state.players;
  for (let i = 0; i < ps.length; i++) for (let j = i + 1; j < ps.length; j++) {
    const a = ps[i], c = ps[j];
    if (a.st === 'dunk' || c.st === 'dunk' || a.st === 'hang' || c.st === 'hang') continue;
    if (Math.abs(a.y - c.y) > 90) continue;
    const dx = c.x - a.x, min = 40;
    if (Math.abs(dx) < min) { const push = (min - Math.abs(dx)) / 2 * (dx === 0 ? 1 : sign(dx)); a.x -= push * 0.5; c.x += push * 0.5; }
  }
  updateBall(dt);

  // phases
  if (state.phase === 'tipoff' && state.phaseT > 3.2 && !state.ball.owner) {
    // nobody tipped: give to random
    state.phase = 'play';
  }
  if (state.phase === 'play') {
    if (state.overtime) { /* sudden death: no clock */ }
    else if (!state.clockOut) {
      state.clock -= dt;
      if (state.clock <= 0) {
        state.clock = 0; state.clockOut = true; Audio.buzzer();
        const b = state.ball;
        if (!(b.inShot && !b.owner)) { state.phase = 'end'; state.phaseT = 0; }
        else banner('BUZZER BEATER?', '', '#ffd23f', 1.2);
      }
    } else {
      const b = state.ball;
      if (b.owner || !b.inShot) { state.phase = 'end'; state.phaseT = 0; }
    }
    // shot clock
    if (state.possTeam >= 0 && !state.clockOut && !state.overtime) {
      const b = state.ball;
      const live = b.owner ? b.owner.team === state.possTeam : !b.rimTouched && b.lastTeam === state.possTeam;
      if (live) {
        state.shotClock -= dt;
        if (state.shotClock <= 0 && !(b.inShot && !b.owner)) {
          Audio.buzzer();
          banner('SHOT CLOCK', 'violation', '#ff5a5a', 1.2);
          state.phase = 'violation'; state.phaseT = 0;
          state.violTeam = 1 - state.possTeam;
        }
      }
    }
  }
  if (state.phase === 'scored' && state.phaseT > 1.35) { state.phase = 'play'; resetPossession(1 - state.lastScorer); }
  if (state.phase === 'violation' && state.phaseT > 1.2) { state.phase = 'play'; resetPossession(state.violTeam); }
  if (state.phase === 'end' && state.phaseT > 1.4 && state.mode !== 'over') {
    if (state.score[0] === state.score[1]) {
      state.overtime = true; state.clockOut = false; state.clock = 0;
      banner('OVERTIME', 'next bucket wins', '#ffd23f', 1.8);
      startTipoff(); state.banner = { text: 'OVERTIME', sub: 'next bucket wins', t: 0, dur: 1.8, color: '#ffd23f' };
    } else if (state.mode === 'playing') endGame();
    else if (state.mode === 'attract') { setupMatch(); }
  }
}

// ───────────────────────── rendering ─────────────────────────
const crowd = [];
(function buildCrowd() {
  const cols = ['#e85d3a', '#2e86de', '#f6d55c', '#3caea3', '#ed553b', '#9b59b6', '#ecf0f1', '#ff9ff3', '#20639b', '#173f5f', '#ffb142', '#ff7a1a', '#19c3b4'];
  for (let row = 0; row < 9; row++) {
    const y = 128 + row * 33, gapX = 30 - row * 0.4;
    for (let x = -10 + (row % 2) * 15; x < W + 20; x += gapX) {
      crowd.push({ x: x + rand(-4, 4), y: y + rand(-3, 3), row, c: pick(cols), skin: pick(SKINS), ph: rand(0, 6.28), sz: 11 + row * 0.35, fan: Math.random() < 0.03 });
    }
  }
})();
let flashes = [];

function drawArena(c) {
  // backdrop
  const g = c.createLinearGradient(0, 0, 0, FLOOR);
  g.addColorStop(0, '#070914'); g.addColorStop(0.55, '#141a36'); g.addColorStop(1, '#1d2246');
  c.fillStyle = g; c.fillRect(0, 0, W, FLOOR);
  // lights
  for (let i = 0; i < 6; i++) {
    const lx = 110 + i * 212;
    const lg = c.createRadialGradient(lx, 22, 2, lx, 22, 180);
    lg.addColorStop(0, 'rgba(255,240,210,0.28)'); lg.addColorStop(1, 'rgba(255,240,210,0)');
    c.fillStyle = lg; c.fillRect(lx - 180, 0, 360, 220);
    c.fillStyle = '#fff8e8'; c.fillRect(lx - 16, 14, 32, 6);
  }
  // crowd
  const hype = state.crowdHype;
  for (const f of crowd) {
    const bob = Math.sin(state.t * (3 + hype * 6) + f.ph) * (1 + hype * 5);
    const shade = 0.42 + f.row * 0.055;
    c.globalAlpha = shade;
    c.fillStyle = f.c; c.beginPath(); c.ellipse(f.x, f.y + 16 + bob * 0.5, f.sz * 0.95, f.sz * 0.8, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = f.skin; c.beginPath(); c.arc(f.x, f.y + bob, f.sz * 0.55, 0, Math.PI * 2); c.fill();
    if (hype > 0.5 && f.fan) { c.fillStyle = f.c; c.fillRect(f.x - 3, f.y - 22 + bob, 6, 14); }
  }
  c.globalAlpha = 1;
  // camera flashes
  if (Math.random() < 0.04 + state.crowdHype * 0.4) flashes.push({ x: rand(0, W), y: rand(120, 400), t: 0 });
  for (const f of flashes) { f.t += 1 / 60; const a = 1 - f.t / 0.15; if (a > 0) { c.fillStyle = `rgba(255,255,255,${a})`; c.beginPath(); c.arc(f.x, f.y, 4 + a * 6, 0, Math.PI * 2); c.fill(); } }
  flashes = flashes.filter((f) => f.t < 0.15);
  // vignette over crowd
  const vg = c.createLinearGradient(0, 100, 0, 440);
  vg.addColorStop(0, 'rgba(7,9,20,0.6)'); vg.addColorStop(1, 'rgba(7,9,20,0.05)');
  c.fillStyle = vg; c.fillRect(0, 100, W, 340);
  // ad board
  c.fillStyle = '#0d1126'; c.fillRect(0, 432, W, 46);
  c.fillStyle = '#1a2150'; c.fillRect(0, 432, W, 3);
  c.font = '400 22px Bungee, sans-serif'; c.textBaseline = 'middle'; c.textAlign = 'left';
  const ads = ['SLAM HEADS', '★', 'BIG HEAD LEAGUE', '★', 'BUCKETS ONLY', '★', 'NO LAYUPS', '★'];
  let ax = -((state.t * 40) % 1400);
  for (let k = 0; k < 3; k++) for (let i = 0; i < ads.length; i++) {
    c.fillStyle = i % 2 ? '#ffd23f' : (i % 4 === 0 ? '#ff7a1a' : '#19c3b4');
    c.fillText(ads[i], ax, 456); ax += c.measureText(ads[i]).width + 34;
  }
  // wall below ad board
  c.fillStyle = '#10142c'; c.fillRect(0, 478, W, FLOOR - 478 - 40);
  // floor
  const fy = FLOOR - 42;
  const fg = c.createLinearGradient(0, fy, 0, H);
  fg.addColorStop(0, '#c98a4b'); fg.addColorStop(0.3, '#d99a58'); fg.addColorStop(1, '#a86a33');
  c.fillStyle = fg; c.fillRect(0, fy, W, H - fy);
  c.strokeStyle = 'rgba(90,50,20,0.22)'; c.lineWidth = 1;
  for (let y = fy + 8; y < H; y += 10 + (y - fy) * 0.06) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
  for (let i = 0; i < 40; i++) { const x = (i * 97) % W; const y = fy + ((i * 37) % (H - fy)); c.beginPath(); c.moveTo(x, y); c.lineTo(x, y + 9); c.stroke(); }
  // reflections
  c.fillStyle = 'rgba(255,240,210,0.08)';
  for (let i = 0; i < 6; i++) c.fillRect(110 + i * 212 - 30, fy, 60, H - fy);
  // court paint: keys
  c.fillStyle = 'rgba(255,122,26,0.32)';
  c.beginPath(); c.moveTo(0, fy + 2); c.lineTo(250, fy + 2); c.lineTo(280, H); c.lineTo(0, H); c.fill();
  c.fillStyle = 'rgba(25,195,180,0.32)';
  c.beginPath(); c.moveTo(W, fy + 2); c.lineTo(W - 250, fy + 2); c.lineTo(W - 280, H); c.lineTo(W, H); c.fill();
  c.strokeStyle = 'rgba(255,255,255,0.75)'; c.lineWidth = 3;
  c.beginPath(); c.moveTo(0, fy + 1); c.lineTo(W, fy + 1); c.stroke();
  // half court + circle
  c.beginPath(); c.moveTo(W / 2, fy + 1); c.lineTo(W / 2, H); c.stroke();
  c.beginPath(); c.ellipse(W / 2, FLOOR + 18, 120, 40, 0, 0, Math.PI * 2); c.stroke();
  c.fillStyle = 'rgba(255,210,63,0.9)'; c.font = '400 26px Bungee, sans-serif'; c.textAlign = 'center';
  c.save(); c.translate(W / 2, FLOOR + 22); c.scale(1, 0.45); c.fillText('SH', 0, 0); c.restore();
  // 3pt lines
  for (const h of HOOPS) {
    const x3 = h.cx - h.dir * THREE_DIST;
    c.strokeStyle = 'rgba(255,255,255,0.75)';
    c.beginPath(); c.moveTo(x3 + h.dir * 14, fy + 1); c.lineTo(x3 - h.dir * 8, H); c.stroke();
    c.beginPath(); c.moveTo(h.boardX + h.dir * 40 - h.dir * 210, fy + 1); c.lineTo(h.boardX - h.dir * 240, H); c.stroke();
  }
}

function drawHoopBack(c, h) {
  const sh = Math.sin(state.t * 60) * h.shake * 3;
  // pole and arm
  const poleX = h.dir > 0 ? W - 22 : 22;
  c.fillStyle = '#2a2f4d'; c.fillRect(poleX - 8, RIM_Y - 70, 16, FLOOR - (RIM_Y - 70) + 6);
  c.fillStyle = '#ff5a5a'; c.fillRect(poleX - 12, FLOOR - 120, 24, 120);
  c.fillStyle = '#2a2f4d';
  c.beginPath(); c.moveTo(poleX, RIM_Y - 70); c.lineTo(h.boardX + h.dir * 4, RIM_Y - 58); c.lineTo(h.boardX + h.dir * 4, RIM_Y - 44); c.lineTo(poleX, RIM_Y - 52); c.fill();
  // backboard glass (slightly skewed)
  const bx = h.boardX + sh * 0.3;
  c.fillStyle = 'rgba(200,230,255,0.25)'; c.strokeStyle = '#f4efe6'; c.lineWidth = 3;
  c.beginPath();
  c.moveTo(bx - h.dir * 2, RIM_Y - 116); c.lineTo(bx - h.dir * 34, RIM_Y - 104); c.lineTo(bx - h.dir * 34, RIM_Y + 14); c.lineTo(bx - h.dir * 2, RIM_Y + 22); c.closePath();
  c.fill(); c.stroke();
  c.strokeStyle = '#ff5a5a'; c.lineWidth = 2;
  c.strokeRect(Math.min(bx - h.dir * 10, bx - h.dir * 28), RIM_Y - 44, 18, 36);
  // back of rim
  c.strokeStyle = '#ff6a00'; c.lineWidth = 4;
  c.beginPath(); c.ellipse(h.cx, RIM_Y + sh * 0.5, 36, 7, 0, Math.PI, Math.PI * 2); c.stroke();
}
function drawHoopFront(c, h) {
  const sh = Math.sin(state.t * 60) * h.shake * 3;
  const ry = RIM_Y + sh * 0.5;
  // net
  const n = h.net, sw = Math.sin(state.t * 30) * n * 6;
  c.strokeStyle = 'rgba(255,255,255,0.85)'; c.lineWidth = 1.6;
  const top = [], bot = [];
  for (let i = 0; i <= 6; i++) { const t = i / 6; top.push([h.minX + 2 + t * (h.maxX - h.minX - 4), ry + 2]); bot.push([h.cx - 20 + t * 40 + sw * (1 - Math.abs(t - 0.5)), ry + 50 + n * 14]); }
  c.beginPath();
  for (let i = 0; i <= 6; i++) { c.moveTo(top[i][0], top[i][1]); c.lineTo(bot[Math.min(6, i + 1)][0], bot[Math.min(6, i + 1)][1]); c.moveTo(top[i][0], top[i][1]); c.lineTo(bot[Math.max(0, i - 1)][0], bot[Math.max(0, i - 1)][1]); }
  for (let k = 1; k <= 3; k++) { const t = k / 4; c.moveTo(lerp(top[0][0], bot[0][0], t), lerp(top[0][1], bot[0][1], t)); for (let i = 1; i <= 6; i++) c.lineTo(lerp(top[i][0], bot[i][0], t), lerp(top[i][1], bot[i][1], t)); }
  c.stroke();
  // front rim
  c.strokeStyle = '#ff7a1a'; c.lineWidth = 5;
  c.beginPath(); c.ellipse(h.cx, ry, 36, 7, 0, 0, Math.PI); c.stroke();
  c.fillStyle = '#ff7a1a'; c.beginPath(); c.arc(h.frontX, ry, 3.5, 0, Math.PI * 2); c.fill();
}

function drawBall(c) {
  const b = state.ball;
  // shadow
  const sh = clamp(1 - (FLOOR - b.y) / 500, 0.2, 1);
  c.fillStyle = `rgba(0,0,0,${0.3 * sh})`; c.beginPath(); c.ellipse(b.x, FLOOR + 4, 14 * sh, 4 * sh, 0, 0, Math.PI * 2); c.fill();
  const fire = b.owner ? b.owner.fire : b.shooter && b.shooter.fire && b.inShot;
  const trailSkin = BALL_TRAILS[wallet.equippedTrail] || BALL_TRAILS.classic;
  if (!b.owner && b.trail.length > 1 && (b.inShot || Math.abs(b.vx) + Math.abs(b.vy) > 130 || fire)) {
    c.save();
    c.globalCompositeOperation = 'lighter';
    c.shadowColor = trailSkin.colors[0];
    c.shadowBlur = trailSkin.style === 'classic' || trailSkin.style === 'fire' ? 18 : 24;
    for (let i = 0; i < b.trail.length; i++) {
      const t = (i + 1) / b.trail.length;
      const pt = b.trail[i];
      let col = trailSkin.colors[Math.min(trailSkin.colors.length - 1, Math.floor((1 - t) * trailSkin.colors.length))];
      if (trailSkin.style === 'rainbow') col = `hsl(${(state.t * 180 + i * 38) % 360} 100% 65%)`;
      c.globalAlpha = 0.12 + t * 0.75;
      c.fillStyle = col;
      const radius = BALL_R * (0.18 + t * (trailSkin.style === 'gold' ? 1.15 : 0.95));
      c.beginPath(); c.arc(pt.x, pt.y, radius, 0, Math.PI * 2); c.fill();
      if (i % 2 === 0 && t > 0.4) {
        c.globalAlpha = t * 0.75;
        c.strokeStyle = col; c.lineWidth = 1.5 + t;
        c.beginPath(); c.moveTo(pt.x - radius * 1.4, pt.y); c.lineTo(pt.x + radius * 1.4, pt.y); c.stroke();
      }
    }
    c.restore();
  }
  b.rot = (b.rot || 0) + (b.owner ? 0.1 : b.spin * 0.016 + b.vx * 0.0003);
  c.save(); c.translate(b.x, b.y); c.rotate(b.rot);
  if (!b.owner && (b.inShot || fire)) {
    c.shadowColor = fire ? '#ff6a16' : '#fff0b2';
    c.shadowBlur = fire ? 22 : 10;
  }
  const g = c.createRadialGradient(-4, -5, 2, 0, 0, BALL_R);
  g.addColorStop(0, '#ffa257'); g.addColorStop(1, '#d1550e');
  c.fillStyle = g; c.beginPath(); c.arc(0, 0, BALL_R, 0, Math.PI * 2); c.fill();
  c.strokeStyle = '#3a1a06'; c.lineWidth = 1.6;
  c.beginPath(); c.arc(0, 0, BALL_R, 0, Math.PI * 2); c.stroke();
  c.beginPath(); c.moveTo(-BALL_R, 0); c.lineTo(BALL_R, 0); c.moveTo(0, -BALL_R); c.lineTo(0, BALL_R); c.stroke();
  c.beginPath(); c.arc(-BALL_R * 1.25, 0, BALL_R * 0.85, -0.9, 0.9); c.stroke();
  c.beginPath(); c.arc(BALL_R * 1.25, 0, BALL_R * 0.85, Math.PI - 0.9, Math.PI + 0.9); c.stroke();
  c.restore();
}

function drawPlayer(c, p) {
  const L = p.look, b = state.ball;
  const outfit = L.outfit && cosmeticById['outfit_' + L.outfit];
  const outfitColors = outfit && outfit.colors;
  const T = outfitColors ? { main:outfitColors[0], dark:outfitColors[1], trim:outfitColors[2], num:outfitColors[3] } : TEAMS[p.team];
  const hasBall = b.owner === p;
  const f = p.facing;
  const air = !p.onGround;
  // shadow
  const hgt = FLOOR - p.y;
  const ss = clamp(1 - hgt / 400, 0.35, 1);
  c.fillStyle = `rgba(0,0,0,${0.32 * ss})`; c.beginPath(); c.ellipse(p.x, FLOOR + 4, 30 * ss, 7 * ss, 0, 0, Math.PI * 2); c.fill();

  // Player VFX: team-colored foot glow, sprint streaks, and a jump halo.
  // These are canvas effects (no external assets) so they stay crisp on mobile.
  const teamGlow = p.human === 1 ? '#79f7ee' : p.human === 0 ? '#ffd34f' : T.trim;
  const fastRun = p.onGround && Math.abs(p.vx) > 185;
  if (fastRun || p.powerT > 0 || p.fire) {
    const pulse = 0.62 + Math.sin(state.t * 15 + p.id.length) * 0.18;
    c.save();
    c.globalAlpha = fastRun ? 0.24 : 0.34 + pulse * 0.16;
    c.shadowColor = p.fire ? '#ff6b21' : teamGlow;
    c.shadowBlur = p.fire ? 24 : 18;
    c.fillStyle = p.fire ? 'rgba(255,105,30,0.36)' : teamGlow;
    c.beginPath(); c.ellipse(p.x, FLOOR - 1, 25 + pulse * 5, 7 + pulse * 2, 0, 0, Math.PI * 2); c.fill();
    c.restore();
  }
  if (fastRun) {
    const dir = p.vx > 0 ? -1 : 1;
    c.save(); c.lineCap = 'round';
    for (let i = 0; i < 4; i++) {
      const flicker = 0.55 + 0.45 * Math.sin(state.t * 24 + i * 1.7 + p.x * 0.02);
      c.globalAlpha = 0.12 + flicker * 0.24;
      c.strokeStyle = i % 2 ? teamGlow : '#ffffff';
      c.lineWidth = 2 + (i % 2);
      const yy = p.y - 40 - i * 21 + Math.sin(state.t * 18 + i) * 3;
      c.beginPath(); c.moveTo(p.x + dir * (19 + i * 4), yy);
      c.lineTo(p.x + dir * (38 + i * 13), yy + (i - 1.5) * 2); c.stroke();
    }
    c.restore();
  }
  if (!p.onGround) {
    const jump = clamp((FLOOR - p.y) / 170, 0, 1);
    c.save(); c.globalAlpha = 0.12 + jump * 0.18;
    c.strokeStyle = p.fire ? '#ff7a22' : teamGlow; c.lineWidth = 2 + jump * 2;
    c.shadowColor = c.strokeStyle; c.shadowBlur = 12;
    c.beginPath(); c.ellipse(p.x, p.y - 72, 27 + Math.sin(state.t * 12) * 3, 53 + jump * 12, Math.sin(state.t * 2) * 0.08, 0, Math.PI * 2); c.stroke();
    c.restore();
  }
  if (p.st === 'dunk' || p.st === 'hang' || p.celebrate > 0) {
    const pulse = 0.5 + 0.5 * Math.sin(state.t * 18);
    c.save(); c.globalAlpha = 0.3 + pulse * 0.35; c.strokeStyle = '#ffe56b'; c.lineWidth = 2.5;
    c.shadowColor = '#ffb52e'; c.shadowBlur = 18;
    c.beginPath(); c.ellipse(p.x, p.y - 92, 34 + pulse * 8, 63 + pulse * 5, 0, 0, Math.PI * 2); c.stroke();
    for (let i = 0; i < 4; i++) {
      const a = state.t * 2.2 + i * Math.PI / 2;
      const sx = p.x + Math.cos(a) * (34 + pulse * 7), sy = p.y - 92 + Math.sin(a) * (62 + pulse * 5);
      c.globalAlpha = 0.55 + pulse * 0.35; c.fillStyle = '#fff5bd';
      c.beginPath(); c.arc(sx, sy, 2.2 + pulse, 0, Math.PI * 2); c.fill();
    }
    c.restore();
  }

  // temporary power-up aura
  if (p.powerT > 0) {
    const pulse = 0.5 + Math.sin(state.t * 18) * 0.12;
    const glow = c.createRadialGradient(p.x, p.y - 90, 12, p.x, p.y - 90, 76);
    glow.addColorStop(0, `rgba(255,210,63,${0.24 * pulse})`);
    glow.addColorStop(1, 'rgba(25,195,180,0)');
    c.fillStyle = glow; c.beginPath(); c.arc(p.x, p.y - 90, 76, 0, Math.PI * 2); c.fill();
  }
  // fire aura
  if (p.fire) {
    for (let i = 0; i < 2; i++) state.particles.push({ x: p.x + rand(-34, 34), y: p.y - rand(10, 170), vx: rand(-20, 20), vy: rand(-180, -70), life: 0.45, max: 0.45, c: pick(['#ff5a1a', '#ffb000', '#ffd23f']), g: -100, s: rand(5, 10), round: true, back: true });
  }

  c.save();
  c.translate(p.x, p.y);
  const sq = p.squash * 0.12;
  c.scale(1 + sq, 1 - sq);
  const run = p.run;
  const moving = Math.abs(p.vx) > 40 && p.onGround;
  const legA = moving ? Math.sin(run) * 0.7 : 0;
  // legs
  c.lineCap = 'round';
  const drawLeg = (ang, back) => {
    c.save(); c.translate(back ? -5 * f : 5 * f, -46);
    let a = ang; if (air) a = back ? -0.5 * f : 0.35 * f;
    c.rotate(a);
    c.strokeStyle = L.skin; c.lineWidth = 11; c.beginPath(); c.moveTo(0, 0); c.lineTo(0, 34); c.stroke();
    c.strokeStyle = '#fafafa'; c.lineWidth = 11; c.beginPath(); c.moveTo(0, 24); c.lineTo(0, 34); c.stroke(); // socks
    c.fillStyle = back ? '#222' : '#2b2b2b'; c.beginPath(); c.ellipse(5 * f, 40, 12, 6, 0, 0, Math.PI * 2); c.fill();
    c.fillStyle = T.main; c.fillRect(-4 + 2 * f, 36, 12, 3);
    c.restore();
  };
  drawLeg(-legA, true);
  // back arm
  const shoulderY = -96;
  const armTo = (tx, ty, back) => {
    c.strokeStyle = L.skin; c.lineWidth = 10;
    const sx = back ? -10 * f : 10 * f;
    const mx = (sx + tx) / 2 + (back ? -6 : 6) * f, my = (shoulderY + ty) / 2 + 6;
    c.beginPath(); c.moveTo(sx, shoulderY); c.quadraticCurveTo(mx, my, tx, ty); c.stroke();
    c.fillStyle = L.skin; c.beginPath(); c.arc(tx, ty, 6, 0, Math.PI * 2); c.fill();
  };
  // compute hand targets
  let fh = [18 * f, -58], bh = [-14 * f, -60];
  const ballLocal = [(b.x - p.x) / (1 + sq), (b.y - p.y) / (1 - sq)];
  if (hasBall) {
    if (p.st === 'shoot' || p.st === 'dunk') { fh = [ballLocal[0] + 4 * f, ballLocal[1] + 8]; bh = [ballLocal[0] - 10 * f, ballLocal[1] + 6]; }
    else if (air) { fh = [ballLocal[0] + 2 * f, ballLocal[1] + 4]; bh = [ballLocal[0] - 12 * f, ballLocal[1]]; }
    else { fh = [ballLocal[0], Math.min(ballLocal[1] - 12, -54)]; bh = [-12 * f, -62]; }
  } else if (p.st === 'release') { fh = [22 * f, -190]; bh = [10 * f, -186]; }
  else if (p.st === 'hang') { fh = [16 * f, -128]; bh = [2 * f, -130]; }
  else if (p.swipeT > 0) { const t = 1 - p.swipeT / 0.22; fh = [lerp(10, 50, Math.sin(t * Math.PI)) * f, -80 + t * 30]; }
  else if (air) { fh = [16 * f, -178]; bh = [-6 * f, -182]; }
  else if (p.celebrate > 0) { fh = [14 * f, -170 - Math.sin(state.t * 20) * 6]; bh = [-14 * f, -168]; }
  else if (moving) { fh = [Math.sin(run) * 18 * f, -58]; bh = [-Math.sin(run) * 16 * f, -60]; }
  else if (!hasBall && b.owner && b.owner.team !== p.team) { fh = [26 * f, -74 + Math.sin(state.t * 8) * 4]; bh = [-20 * f, -76]; } // defensive stance
  armTo(bh[0], bh[1], true);
  // shorts
  c.fillStyle = T.dark; c.beginPath(); c.roundRect(-19, -64, 38, 24, 5); c.fill();
  c.fillStyle = T.trim; c.fillRect(-19, -46, 38, 3);
  drawLeg(legA, false);
  // torso
  c.fillStyle = T.main; c.beginPath(); c.roundRect(-20, -104, 40, 46, 9); c.fill();
  c.fillStyle = T.trim; c.fillRect(-20, -104, 40, 4);
  c.fillStyle = T.num; c.font = '400 17px Bungee, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
  c.fillText(String(L.num), 2 * f, -80);
  // front arm
  armTo(fh[0], fh[1], false);
  c.restore();

  // big head (not squashed)
  const hy = p.y - 136 - (p.squash * 4), hx = p.x + 2 * f, r = L.headR;
  c.save(); c.translate(hx, hy);
  // A soft rim light makes the player's head and hairstyle pop from the court.
  if (p.powerT > 0 || p.fire || p.st === 'dunk' || p.st === 'hang') {
    c.save(); c.globalAlpha = 0.72; c.shadowColor = p.fire ? '#ff792d' : (p.st === 'dunk' || p.st === 'hang' ? '#ffe36c' : teamGlow);
    c.shadowBlur = 18; c.strokeStyle = c.shadowColor; c.lineWidth = 2.5;
    c.beginPath(); c.arc(0, 0, r + 2.5, 0, Math.PI * 2); c.stroke(); c.restore();
  }
  // neck
  c.fillStyle = L.skin; c.fillRect(-7, r - 10, 14, 14);
  // hair back layers
  c.fillStyle = L.hair;
  if (L.style === 'afro') { c.beginPath(); c.arc(-3 * f, -6, r + 12, 0, Math.PI * 2); c.fill(); }
  if (L.style === 'bun') { c.beginPath(); c.arc(-r * 0.7 * f, -r * 0.9, 11, 0, Math.PI * 2); c.fill(); }
  // ear
  c.fillStyle = L.skin; c.beginPath(); c.arc(-6 * f, 4, 8, 0, Math.PI * 2); c.fill();
  // head
  c.beginPath(); c.arc(0, 0, r, 0, Math.PI * 2); c.fill();
  c.fillStyle = 'rgba(0,0,0,0.08)'; c.beginPath(); c.arc(-6 * f, 4, r - 2, Math.PI * 0.5, Math.PI * 1.5, f > 0); c.fill();
  // hair front
  c.fillStyle = L.hair;
  if (L.style === 'fade' || L.style === 'bun') { c.beginPath(); c.arc(0, -2, r + 1, Math.PI * 1.05, Math.PI * 1.95); c.quadraticCurveTo(0, -r * 0.55, -r * f, -2); c.fill(); }
  else if (L.style === 'spike') { c.beginPath(); c.moveTo(-r, -6); for (let i = 0; i <= 6; i++) { const a = Math.PI + (i / 6) * Math.PI; c.lineTo(Math.cos(a) * (r + (i % 2 ? 12 : 2)), Math.sin(a) * (r + (i % 2 ? 12 : 2)) - 4); } c.lineTo(r, -6); c.fill(); }
  else if (L.style === 'flat') { c.fillRect(-r + 2, -r - 12, r * 2 - 4, 22); }
  else if (L.style === 'afro') { c.beginPath(); c.arc(0, -r * 0.45, r * 0.95, Math.PI, Math.PI * 2); c.fill(); }
  // headband
  if (L.band) { c.fillStyle = T.trim; c.fillRect(-r + 1, -r * 0.42, r * 2 - 2, 8); c.fillStyle = T.main; c.fillRect(-r + 1, -r * 0.42 + 3, r * 2 - 2, 2); }
  // face
  const ex = 12 * f, ey = -2;
  const focus = (p.st === 'shoot' || p.st === 'dunk');
  c.fillStyle = '#fff'; c.beginPath(); c.ellipse(ex, ey, 7, focus ? 4 : 8, 0, 0, Math.PI * 2); c.fill();
  c.beginPath(); c.ellipse(ex - 13 * f, ey, 5.5, focus ? 3.5 : 7, 0, 0, Math.PI * 2); c.fill();
  c.fillStyle = '#1b1410'; c.beginPath(); c.arc(ex + 3 * f, ey + 1, 3.6, 0, Math.PI * 2); c.fill();
  c.beginPath(); c.arc(ex - 10 * f, ey + 1, 3, 0, Math.PI * 2); c.fill();
  // brows
  c.strokeStyle = L.hair === '#e6e0d8' ? '#6b5f55' : L.hair; c.lineWidth = 3.4; c.lineCap = 'round';
  const angry = focus || (b.owner && b.owner.team !== p.team);
  c.beginPath(); c.moveTo(ex - 6 * f, ey - 11 + (angry ? 2 : 0)); c.lineTo(ex + 7 * f, ey - (angry ? 9 : 12)); c.stroke();
  // nose & mouth
  c.strokeStyle = 'rgba(0,0,0,0.35)'; c.lineWidth = 2;
  c.beginPath(); c.moveTo(r * 0.72 * f, 4); c.lineTo(r * 0.82 * f, 10); c.lineTo(r * 0.6 * f, 11); c.stroke();
  c.strokeStyle = '#4a1f14'; c.lineWidth = 2.6;
  c.beginPath();
  if (p.celebrate > 0 || p.st === 'dunk' || p.st === 'hang') { c.fillStyle = '#4a1f14'; c.ellipse(9 * f, 19, 7, 5, 0, 0, Math.PI); c.fill(); }
  else c.moveTo(3 * f, 19), c.quadraticCurveTo(9 * f, angry ? 18 : 22, 15 * f, 18), c.stroke();
  if (L.beard) { c.fillStyle = L.hair; c.beginPath(); c.moveTo(-4 * f, 14); c.quadraticCurveTo(2 * f, r + 4, 18 * f, 26); c.quadraticCurveTo(24 * f, 24, 26 * f, 16); c.quadraticCurveTo(14 * f, r - 2, -4 * f, 14); c.fill(); }
  c.restore();

  // marker
  if (p.human >= 0 || state.players.length > 2) {
    const my = p.y - 136 - r - 26 + Math.sin(state.t * 5) * 2;
    c.fillStyle = p.human >= 0 ? (p.human === 0 ? '#ffd23f' : '#9ef7ee') : 'rgba(255,255,255,0.5)';
    c.beginPath(); c.moveTo(p.x - 7, my - 10); c.lineTo(p.x + 7, my - 10); c.lineTo(p.x, my); c.fill();
    c.font = '700 13px Rubik, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'bottom';
    c.fillText(p.label, p.x, my - 12);
  }

  // shot meter
  if (p.st === 'shoot' && hasBall) {
    const mx = p.x - f * 52, myT = p.y - 200, mh = 84;
    const timing = clamp(p.vy / SHOT_JUMP_V, -1, 0.6); // -1..0.6
    const fill = clamp((timing + 1) / 1.6, 0, 1);
    const gw = p.fire ? 0.2 : 0.12;
    c.fillStyle = 'rgba(8,10,22,0.8)'; c.beginPath(); c.roundRect(mx - 9, myT - 4, 18, mh + 8, 6); c.fill();
    // green zone (apex) at timing 0 => fill 1/1.6
    const gz = (1 / 1.6);
    const gTop = myT + mh * (1 - (gz + gw / 1.6)), gBot = myT + mh * (1 - (gz - gw / 1.6));
    c.fillStyle = 'rgba(125,255,107,0.35)'; c.fillRect(mx - 6, gTop, 12, gBot - gTop);
    const inGreen = Math.abs(timing) <= gw;
    c.fillStyle = inGreen ? '#7dff6b' : '#ffd23f';
    c.fillRect(mx - 5, myT + mh * (1 - fill), 10, mh * fill);
    c.strokeStyle = '#fff'; c.lineWidth = 1.5; c.strokeRect(mx - 6, gTop, 12, gBot - gTop);
  }
}

function drawParticles(c, back = false) {
  for (const q of state.particles) {
    if (!!q.back !== back) continue;
    const a = clamp(q.life / q.max, 0, 1);
    c.globalAlpha = a;
    if (q.glow) {
      c.shadowColor = q.c;
      c.shadowBlur = q.ring ? 18 : 12;
    }
    c.strokeStyle = q.c; c.fillStyle = q.c;
    if (q.ring) {
      const progress = 1 - a;
      c.lineWidth = Math.max(1, 5 * a);
      c.beginPath();
      c.arc(q.x, q.y, 8 + progress * q.s, 0, Math.PI * 2);
      c.stroke();
      c.shadowBlur = 0;
    } else if (q.streak) {
      c.lineWidth = Math.max(1, q.s * a);
      c.beginPath(); c.moveTo(q.x, q.y); c.lineTo(q.x - q.vx * 0.035, q.y - q.vy * 0.035); c.stroke();
    } else if (q.round) {
      c.beginPath(); c.arc(q.x, q.y, q.s * (0.5 + a * 0.5), 0, Math.PI * 2); c.fill();
    } else {
      c.fillRect(q.x - q.s / 2, q.y - q.s / 2, q.s, q.s);
    }
    c.shadowBlur = 0;
  }
  c.globalAlpha = 1;
}

function fmtClock(s) {
  if (s >= 10) { const m = Math.floor(s / 60), r = Math.floor(s % 60); return `${m}:${String(r).padStart(2, '0')}`; }
  return s.toFixed(1);
}

function drawHUD(c) {
  // scoreboard
  const cx = W / 2, y = 14, w = 470, h = 72;
  c.fillStyle = 'rgba(6,8,18,0.88)'; c.beginPath(); c.roundRect(cx - w / 2, y, w, h, 12); c.fill();
  c.strokeStyle = 'rgba(255,255,255,0.12)'; c.lineWidth = 1; c.stroke();
  // team blocks
  for (let t = 0; t < 2; t++) {
    const T = TEAMS[t], sx = t === 0 ? cx - w / 2 : cx + w / 2 - 170;
    c.fillStyle = T.main; c.beginPath(); c.roundRect(sx + 6, y + 6, 164, h - 12, 8); c.fill();
    c.fillStyle = 'rgba(0,0,0,0.25)'; c.fillRect(sx + (t === 0 ? 96 : 6), y + 6, 74, h - 12);
    c.fillStyle = '#10142c'; c.font = '400 18px Bungee, sans-serif'; c.textBaseline = 'middle';
    c.textAlign = t === 0 ? 'left' : 'right';
    c.fillText(T.name, t === 0 ? sx + 16 : sx + 160, y + 26);
    const who = state.players.filter((p) => p.team === t);
    c.font = '700 12px Rubik, sans-serif'; c.fillStyle = 'rgba(16,20,44,0.8)';
    c.fillText(who.map((p) => p.label).join(' + '), t === 0 ? sx + 16 : sx + 160, y + 48);
    c.fillStyle = '#fff'; c.font = '400 38px Bungee, sans-serif'; c.textAlign = 'center';
    c.fillText(String(state.score[t]), t === 0 ? sx + 133 : sx + 43, y + h / 2 + 2);
    if (state.streak[t] >= 3) { c.fillStyle = '#ffd23f'; c.font = '700 11px Rubik, sans-serif'; c.fillText('HOT', t === 0 ? sx + 133 : sx + 43, y + h - 4); }
  }
  // clock
  c.textAlign = 'center';
  const clockTxt = state.overtime ? 'OT' : fmtClock(Math.max(0, state.clock));
  c.fillStyle = state.clock < 10 && !state.overtime ? '#ff5a5a' : '#ffd23f';
  c.font = '400 28px Bungee, sans-serif'; c.fillText(clockTxt, cx, y + 28);
  // shot clock
  const sc = Math.ceil(Math.max(0, state.shotClock));
  c.font = '700 13px Rubik, sans-serif'; c.fillStyle = 'rgba(255,255,255,0.55)';
  c.fillText('SHOT', cx - 16, y + 56);
  c.fillStyle = sc <= 4 ? '#ff5a5a' : '#f4efe6'; c.font = '400 18px Bungee, sans-serif';
  c.fillText(state.overtime ? '--' : String(sc), cx + 22, y + 56);
  // possession arrow
  if (state.possTeam >= 0 && state.phase === 'play') {
    c.fillStyle = TEAMS[state.possTeam].main;
    const ax = state.possTeam === 0 ? cx - 52 : cx + 52;
    c.beginPath();
    if (state.possTeam === 0) { c.moveTo(ax, y + 22); c.lineTo(ax - 9, y + 28); c.lineTo(ax, y + 34); }
    else { c.moveTo(ax, y + 22); c.lineTo(ax + 9, y + 28); c.lineTo(ax, y + 34); }
    c.fill();
  }

  // floating texts
  for (const t of state.texts) {
    const k = t.t / t.dur;
    c.globalAlpha = 1 - k * k;
    c.font = `400 ${t.size}px Bungee, sans-serif`; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.lineWidth = 5; c.strokeStyle = 'rgba(6,8,18,0.85)';
    c.strokeText(t.text, t.x, t.y - k * 50); c.fillStyle = t.color; c.fillText(t.text, t.x, t.y - k * 50);
  }
  c.globalAlpha = 1;
  // banner
  const B = state.banner;
  if (B && B.text) {
    const k = B.t / B.dur;
    const pop = k < 0.15 ? 0.6 + (k / 0.15) * 0.5 : k < 0.25 ? 1.1 - ((k - 0.15) / 0.1) * 0.1 : 1;
    c.globalAlpha = k > 0.8 ? (1 - k) / 0.2 : 1;
    c.save(); c.translate(W / 2, 250); c.scale(pop, pop); c.rotate(-0.04);
    c.font = '400 76px Bungee, sans-serif'; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.lineWidth = 12; c.strokeStyle = '#0a0c1a'; c.strokeText(B.text, 0, 0);
    c.fillStyle = B.color; c.fillText(B.text, 0, 0);
    if (B.sub) { c.font = '800 22px Rubik, sans-serif'; c.lineWidth = 6; c.strokeText(B.sub.toUpperCase(), 0, 56); c.fillStyle = '#f4efe6'; c.fillText(B.sub.toUpperCase(), 0, 56); }
    c.restore(); c.globalAlpha = 1;
  }
  if (state.mode === 'attract') {
    // nothing extra; menu overlay covers
  }
}

function render() {
  const c = ctx;
  c.setTransform(dpr * scale, 0, 0, dpr * scale, 0, 0);
  let sx = 0, sy = 0;
  if (state.shake > 0) { sx = rand(-1, 1) * state.shake * 16; sy = rand(-1, 1) * state.shake * 12; }
  c.save(); c.translate(sx, sy);
  drawArena(c);
  for (const h of HOOPS) drawHoopBack(c, h);
  // players sorted: non-ball first
  const ps = [...state.players].sort((a, b) => (state.ball.owner === a) - (state.ball.owner === b));
  drawParticles(c, true);
  const atRim = (p) => p.st === 'hang' || (p.st === 'dunk' && p.stT / p.dunk.dur > 0.7);
  for (const p of ps) if (!atRim(p)) drawPlayer(c, p);
  drawBall(c);
  for (const h of HOOPS) drawHoopFront(c, h);
  for (const p of ps) if (atRim(p)) drawPlayer(c, p);
  drawParticles(c);
  c.restore();
  if (state.flash > 0) { c.fillStyle = `rgba(255,255,255,${state.flash * 0.9})`; c.fillRect(0, 0, W, H); }
  drawHUD(c);
}

// ───────────────────────── flow / UI ─────────────────────────
const $ = (id) => document.getElementById(id);
document.querySelectorAll('.seg').forEach((seg) => {
  seg.addEventListener('click', (e) => {
    const btn = e.target.closest('button'); if (!btn) return;
    seg.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b === btn));
    const key = seg.dataset.key, v = btn.dataset.val;
    state.cfg[key] = key === 'len' ? Number(v) : v;
    if (key === 'mode' && v === 'tournament') state.tournamentRound = 1;
    if (Audio.ctx) Audio.tone(660, 0.05, 'sine', 0.06);
  });
});
$('playBtn').addEventListener('click', startGame);
$('openShopBtn').addEventListener('click', () => { renderShop(); $('shop').classList.remove('hidden'); $('menu').classList.add('hidden'); });
$('openCustomizeBtn').addEventListener('click', () => { renderCustomization(); $('customize').classList.remove('hidden'); $('menu').classList.add('hidden'); });
$('openOnlineBtn').addEventListener('click', () => { showOnlinePanel(); setOnlineStatus('Ready! Create a room to get your code, or enter your friend’s 6-digit code.'); });
$('closeOnlineBtn').addEventListener('click', hideOnlinePanel);
$('createRoomBtn').addEventListener('click', () => ensureOnlineSocket({ event: 'room:create', data: {} }));
$('joinRoomBtn').addEventListener('click', () => { const code = $('joinRoomCode').value.trim().toUpperCase(); if (!/^\d{6}$/.test(code)) { onlineError('Enter the 6-digit room code your friend shared.'); return; } ensureOnlineSocket({ event: 'room:join', data: { code } }); });
$('startOnlineBtn').addEventListener('click', () => { if (online.socket && online.role === 0 && online.roomReady) online.socket.emit('room:start', { len: Number(state.cfg.len) || 120 }); });
$('leaveOnlineBtn').addEventListener('click', leaveOnlineRoom);
$('copyRoomCodeBtn').addEventListener('click', async () => { try { await navigator.clipboard.writeText(online.roomCode); setOnlineStatus('Room code copied. Send it to your friend!', 'good'); } catch (_) { setOnlineStatus(`Share this room code with your friend: ${online.roomCode}`, 'good'); } });
$('joinRoomCode').addEventListener('input', () => { $('joinRoomCode').value = $('joinRoomCode').value.replace(/\D/g, '').slice(0,6); });
$('closeCustomizeBtn').addEventListener('click', () => { $('customize').classList.add('hidden'); $('menu').classList.remove('hidden'); updateWalletUI(); });
$('closeShopBtn').addEventListener('click', () => { $('shop').classList.add('hidden'); $('menu').classList.remove('hidden'); updateWalletUI(); });
$('resumeBtn').addEventListener('click', togglePause);
$('quitBtn').addEventListener('click', toMenu);
$('menuBtn').addEventListener('click', toMenu);
$('rematchBtn').addEventListener('click', () => {
  if (state.cfg.mode === 'online') { if (online.role === 0 && online.socket) { state.mode = 'menu'; $('over').classList.add('hidden'); showOnlinePanel(); online.socket.emit('room:start', { len: Number(state.cfg.len) || 120 }); setOnlineStatus('Starting rematch…', 'good'); } else { $('over').classList.add('hidden'); showOnlinePanel(); setOnlineStatus('Waiting for the room host to start the rematch.'); } return; }
  if (state.cfg.mode === 'tournament') {
    if (state.score[0] > state.score[1] && state.tournamentRound < 5) state.tournamentRound++;
    else state.tournamentRound = 1;
  }
  startGame();
});
$('rotate').classList.remove('hidden');
$('pauseBtn').addEventListener('click', togglePause);
$('muteBtn').addEventListener('click', toggleMute);

updateWalletUI();
const isTouch = matchMedia('(pointer: coarse)').matches || 'ontouchstart' in window;
function bindTouchButtons(selector, datasetKey, targetState) {
  document.querySelectorAll(selector).forEach((btn) => {
    const k = btn.dataset[datasetKey];
    const on = (e) => { e.preventDefault(); targetState[k] = true; btn.classList.add('held'); };
    const off = (e) => { e.preventDefault(); targetState[k] = false; btn.classList.remove('held'); };
    btn.addEventListener('pointerdown', on); btn.addEventListener('pointerup', off); btn.addEventListener('pointerleave', off); btn.addEventListener('pointercancel', off);
  });
}
bindTouchButtons('#touch button', 'k', touchState);
bindTouchButtons('#touchP2 button', 'p2k', touchState2);

function startGame() {
  if (state.cfg.mode === 'tournament' && !state.tournamentRound) state.tournamentRound = 1;
  $('shop').classList.add('hidden');
  onlinePanel.classList.add('hidden');
  Audio.init();
  state.mode = 'playing'; document.body.classList.add('ingame');
  $('menu').classList.add('hidden'); $('over').classList.add('hidden'); $('pause').classList.add('hidden');
  $('hudBtns').classList.remove('hidden');
  $('touch').classList.toggle('hidden', !isTouch);
  document.body.classList.toggle('local-pvp', state.cfg.mode === 'pvp' && isTouch);
  $('touchP2').classList.toggle('hidden', !(isTouch && state.cfg.mode === 'pvp'));
  document.querySelector('#touch .tp').style.display = state.cfg.mode === '2v2' ? '' : 'none';
  updateTouchActionUI();
  for (const k in keys) keys[k] = false;
  setupMatch();
  canvas.focus && canvas.focus();
}
function toMenu() {
  document.body.classList.remove('local-pvp');
  $('touchP2').classList.add('hidden');
  for (const k in touchState2) touchState2[k] = false;
  state.mode = 'attract'; document.body.classList.remove('ingame');
  $('menu').classList.remove('hidden'); $('over').classList.add('hidden'); $('pause').classList.add('hidden');
  $('hudBtns').classList.add('hidden'); $('touch').classList.add('hidden');
  const saved = state.cfg.mode; state.cfg.mode = '1v1'; setupMatch(); state.cfg.mode = saved;
}
function togglePause() {
  if (state.cfg.mode === 'online') { setOnlineStatus('Online matches cannot be paused. Finish the match or leave the room.'); return; }
  if (state.mode === 'playing') { state.mode = 'paused'; $('pause').classList.remove('hidden'); }
  else if (state.mode === 'paused') { state.mode = 'playing'; $('pause').classList.add('hidden'); for (const k in keys) keys[k] = false; }
}
function toggleMute() {
  Audio.setMuted(!Audio.muted);
  $('muteBtn').classList.toggle('off', Audio.muted);
}
function endGame() {
  if (!state.coinsAwarded) { const won = state.cfg.mode === 'online' ? (online.role === 0 ? state.score[0] > state.score[1] : state.score[1] > state.score[0]) : state.score[0] > state.score[1]; const tied = state.score[0] === state.score[1]; const earned = state.cfg.mode === 'pvp' ? (tied ? 10 : 25) : state.cfg.mode === 'online' ? (won ? 100 : 25) : state.cfg.mode === 'tournament' ? (won ? 75 * state.tournamentRound : 20) : (won ? 100 : 25); wallet.coins += earned; state.coinsAwarded = true; state.coinsEarned = earned; saveWallet(); }
  state.mode = 'over'; document.body.classList.remove('ingame');
  const [a, b] = state.score;
  const human0Team = 0;
  let title;
  if (state.cfg.mode === 'pvp') title = a > b ? 'P1 WINS' : 'P2 WINS';
  else if (state.cfg.mode === 'online') title = ((online.role === 0 && a > b) || (online.role === 1 && b > a)) ? 'YOU WIN!' : 'YOU LOST';
  else if (state.cfg.mode === 'tournament') title = a > b ? (state.tournamentRound === 5 ? '🏆 TOURNAMENT CHAMPION!' : `ROUND ${state.tournamentRound} CLEARED!`) : 'TOURNAMENT OVER';
  else title = a > b ? 'YOU WIN' : 'CPU WINS';
  $('overTitle').textContent = title;
  $('overTitle').style.color = a > b ? 'var(--orange)' : 'var(--teal)';
  $('overKicker').textContent = `${state.cfg.mode === 'tournament' ? `TOURNAMENT · ROUND ${state.tournamentRound}/5` : (state.overtime ? 'FINAL · OVERTIME' : 'FINAL')} · +${state.coinsEarned} COINS`;
  if (state.cfg.mode === 'online') $('overKicker').textContent = `ONLINE MATCH · ROOM ${online.roomCode} · +${state.coinsEarned} COINS`;
  $('rematchBtn').textContent = state.cfg.mode === 'tournament' && a > b && state.tournamentRound < 5 ? 'NEXT ROUND ▶' : state.cfg.mode === 'tournament' && a > b ? 'PLAY TOURNAMENT AGAIN' : 'REMATCH';
  if (state.cfg.mode === 'tournament' && a > b && state.tournamentRound < 5) { $('overKicker').textContent += ` · NEXT CPU IS STRONGER`; }
  $('finalScore').innerHTML = `<span class="o">${a}</span><span class="d">–</span><span class="t">${b}</span>`;
  const rows = state.players.map((p) => `<tr><td class="nm" style="color:${TEAMS[p.team].main}">${p.name} <span style="color:var(--muted);font-weight:500">${p.label}</span></td><td>${p.stats.pts}</td><td>${p.stats.fgm}/${p.stats.fga}</td><td>${p.stats.tpm}/${p.stats.tpa}</td><td>${p.stats.dunks}</td><td>${p.stats.reb}</td><td>${p.stats.stl}</td><td>${p.stats.blk}</td></tr>`).join('');
  $('statsTable').innerHTML = `<tr><th>Player</th><th>PTS</th><th>FG</th><th>3PT</th><th>DNK</th><th>REB</th><th>STL</th><th>BLK</th></tr>${rows}`;
  $('over').classList.remove('hidden'); $('hudBtns').classList.add('hidden'); $('touch').classList.add('hidden');
  if ((a > b && state.cfg.mode !== 'pvp') || state.cfg.mode === 'pvp') { burst(W / 2, 200, 80, ['#ff7a1a', '#19c3b4', '#ffd23f', '#fff'], 600, 2, 500, 6); Audio.cheer(1.5); }
}

// ───────────────────────── loop ─────────────────────────
const STEP = 1 / 60;
let last = performance.now(), acc = 0;
function frame(now) {
  const elapsed = Math.min(0.1, (now - last) / 1000); last = now;
  if (!(state.cfg.mode === 'online' && online.role === 1 && state.mode === 'playing')) {
    acc += elapsed;
    while (acc >= STEP) { update(STEP); acc -= STEP; }
  } else acc = 0;
  if (state.cfg.mode === 'online' && online.socket && online.socket.connected && (state.mode === 'playing' || state.mode === 'over')) {
    online.inputTimer += elapsed;
    if (online.inputTimer >= 0.05) { online.inputTimer = 0; if (online.role === 1) online.socket.emit('player:input', { role: 1, intent: onlineLocalIntent() }); }
    if (online.role === 0) {
      online.hostSnapshotTimer += elapsed;
      if (online.hostSnapshotTimer >= 0.05) { online.hostSnapshotTimer = 0; online.socket.emit('game:snapshot', makeOnlineSnapshot()); }
    }
  }
  render();
  requestAnimationFrame(frame);
}

// test hooks
window.advanceTime = (ms) => { const n = Math.max(1, Math.round(ms / (1000 / 60))); for (let i = 0; i < n; i++) update(STEP); render(); };
window.render_game_to_text = () => {
  const b = state.ball;
  return JSON.stringify({
    coords: 'origin top-left, x right, y down; floor y=' + FLOOR + '; team0 attacks right hoop x=' + HOOPS[1].cx + ', team1 attacks left hoop x=' + HOOPS[0].cx + ', rimY=' + RIM_Y,
    mode: state.mode, phase: state.phase, score: state.score, clock: +state.clock.toFixed(1), shotClock: +state.shotClock.toFixed(1), possession: state.possTeam, overtime: state.overtime,
    ball: { x: Math.round(b.x), y: Math.round(b.y), vx: Math.round(b.vx), vy: Math.round(b.vy), owner: b.owner ? b.owner.id : null, inShot: b.inShot, rimTouched: b.rimTouched },
    players: state.players.map((p) => ({ id: p.id, team: p.team, ctrl: p.label, x: Math.round(p.x), y: Math.round(p.y), vy: Math.round(p.vy), onGround: p.onGround, st: p.st, fire: p.fire, pts: p.stats.pts })),
  });
};
window.__state = state;

state.mode = 'attract';
const fontsReady = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
fontsReady.then(() => { setupMatch(); requestAnimationFrame(frame); });
})();
