# Slam Heads online multiplayer

This build adds private random 6-digit room codes and real-time 1v1 matches across devices. The static game frontend and the multiplayer server must both be deployed. Netlify alone cannot run the Socket.IO server.

## 1. Deploy the multiplayer server

1. Extract this ZIP and upload the full folder to a new GitHub repository (keep the `server` folder and `render.yaml`).
2. In Render, create a **Blueprint** from that repository, or create a Node web service with root directory `server`, build command `npm install`, and start command `npm start`.
3. Keep the Render service name `slam-heads-multiplayer` from `render.yaml` so its default URL is `https://slam-heads-multiplayer.onrender.com`. Wait until the service is live, then open `/health` at the end of that URL and confirm it returns JSON with `"ok":true`. If Render assigns a different URL, update `DEFAULT_ONLINE_SERVER_URL` near the top of `game.js` once before publishing.

The server keeps rooms in memory, so rooms disappear if the service restarts. This is fine for private friend matches.

## 2. Publish the game frontend

1. Upload `index.html`, `game.js`, and `style.css` to your Netlify site as usual.
2. Open the published game and press **PLAY WITH FRIENDS ONLINE**.
3. The host presses **CREATE NEW ROOM**; the game generates a random 6-digit code.
4. Share the code with your friend. They enter it and press **JOIN ROOM**.
5. When both are connected, the host presses **START MATCH**.

Each player uses the on-screen controls on a phone. On a keyboard, the host uses A/D/W/S/E/Q and the joining player uses arrow keys, Slash/Shift, and N. The game host simulates the match and sends state snapshots to the other player.

## Same-device multiplayer

Choose **👥 Local 2P** from the mode selector and press **TIP OFF**. On desktop, Player 1 uses A/D/W/S and Q for power-ups; Player 2 uses the arrow keys, Slash/Right Shift to pass, and N for power-up. On touch devices, the game displays separate Player 1 controls on the left and Player 2 controls on the right. For the best experience on one phone, rotate it sideways; two controllers can be crowded on a small screen.

Online play remains under **PLAY WITH FRIENDS ONLINE** and uses a 6-digit private room code. Players no longer enter a server URL; the frontend connects to the configured server automatically. Both local and online modes are included in this build.

## Notes

- This is a prototype online 1v1 implementation; reconnecting mid-match and anti-cheat are not implemented.
- Coins, purchases, and cosmetics are saved locally in each player's browser; the server does not store accounts or shared wallets.
- The server allows browser origins for easy static hosting. Do not use this simple prototype as a trusted competitive/ranked backend without additional authentication, rate limiting, and server-authoritative game logic.
